import sys
from pathlib import Path
import numpy as np
import pytest
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from hdcmem.hdc import (random_bipolar, make_level_hvs, bind, sign_tiebreak, UnitScaler, IDLevelEncoder, AssociativeMemory)
from hdcmem.data import load_wine, group_duplicates, make_split, audit_split, to_task
from hdcmem.metrics import evaluate

D = 10000


def cos(a, b):
    a, b = a.astype(float), b.astype(float)
    return a @ b / (np.linalg.norm(a) * np.linalg.norm(b))


# ---------- primitives ----------
def test_random_hvs_quasi_orthogonal():
    rng = np.random.default_rng(0)
    H = random_bipolar(rng, (50, D))
    assert set(np.unique(H)) == {-1, 1}
    C = (H.astype(np.float32) @ H.T.astype(np.float32)) / D
    off = C[~np.eye(50, dtype=bool)]
    assert np.abs(off).max() < 5 / np.sqrt(D) and abs(off.mean()) < 0.005


def test_level_hvs_linear_and_end_orthogonal():
    Q = 32
    L = make_level_hvs(np.random.default_rng(1), Q, D)
    sims = np.array([cos(L[0], L[q]) for q in range(Q)])
    assert np.all(np.diff(sims) < 0)                      # strictly decreasing
    assert abs(sims[-1]) < 1e-12                           # extremes exactly orthogonal
    assert np.allclose(sims, 1 - 2 * np.cumsum([0] + [len(c) for c in np.array_split(np.arange(D // 2), Q - 1)]) / D)


def test_binding_properties():
    rng = np.random.default_rng(2)
    a, b, c = (random_bipolar(rng, (D,)) for _ in range(3))
    assert np.array_equal(bind(bind(a, b), b), a)                        # self-inverse
    assert cos(bind(a, c), bind(b, c)) == pytest.approx(cos(a, b), abs=1e-12)   # similarity preserving
    assert abs(cos(bind(a, b), a)) < 5 / np.sqrt(D)                      # product dissimilar to operands


def test_bundling_retrieves_members():
    rng = np.random.default_rng(3)
    items = random_bipolar(rng, (200, D))
    members = rng.choice(200, size=11, replace=False)
    bundle = sign_tiebreak(items[members].sum(0, dtype=np.int32))
    sims = (items.astype(np.float32) @ bundle.astype(np.float32)) / D
    top = np.argsort(-sims)[:11]
    assert set(top) == set(members)
    non = np.setdiff1d(np.arange(200), members)
    assert sims[non].max() < sims[members].min()


# ---------- encoder ----------
def _toy(n=300, F=11, seed=0):
    r = np.random.default_rng(seed)
    return r.normal(size=(n, F)) * np.arange(1, F + 1) + 5


def test_encoder_deterministic_and_batch_invariant():
    X = _toy()
    e1 = IDLevelEncoder(11, 2000, 16, "minmax", seed=7).fit(X)
    e2 = IDLevelEncoder(11, 2000, 16, "minmax", seed=7).fit(X)
    H = e1.encode(X, chunk=64)
    assert np.array_equal(H, e2.encode(X, chunk=500))
    assert np.array_equal(H[17:18], e1.encode(X[17:18]))
    assert set(np.unique(H)) == {-1, 1}


@pytest.mark.parametrize("scaling", ["minmax", "quantile"])
def test_encoder_similarity_tracks_input_distance(scaling):
    X = _toy()
    e = IDLevelEncoder(11, D, 32, scaling, seed=0).fit(X)
    x = X[:1]
    near, far = x.copy(), x.copy()
    near[0, 0] += 0.2 * X[:, 0].std()
    far[0, :] = X[np.argmax(np.abs(X - x).sum(1))]
    h, hn, hf = e.encode(x)[0], e.encode(near)[0], e.encode(far)[0]
    assert cos(h, hn) > cos(h, hf)


@pytest.mark.parametrize("scaling", ["minmax", "quantile"])
def test_scaler_uses_only_training_data(scaling):
    Xtr, Xother = _toy(seed=1), _toy(seed=2) * 10
    s = UnitScaler(scaling).fit(Xtr)
    a = s.transform(Xtr).copy()
    _ = s.transform(Xother)                       # transforming other data must not change learned state
    assert np.array_equal(a, s.transform(Xtr))
    ref = UnitScaler(scaling).fit(Xtr)
    assert np.array_equal(ref.transform(Xother), s.transform(Xother))
    u = s.transform(Xother)
    assert u.min() >= 0 and u.max() <= 1          # out-of-range test values are clipped, not extrapolated


def test_feature_count_odd_gives_no_bundling_ties():
    X = _toy()
    e = IDLevelEncoder(11, 2000, 16, "minmax", seed=0).fit(X)
    assert (e.encode_sum(X) % 2 != 0).all()       # sum of 11 values of +-1 is odd -> never 0


# ---------- associative memory ----------
def _clusters(n_per=80, K=4, F=11, seed=0):
    r = np.random.default_rng(seed)
    centers = r.normal(size=(K, F)) * 3
    X = np.vstack([c + r.normal(size=(n_per, F)) for c in centers])
    return X, np.repeat(np.arange(K), n_per)


def test_am_separable_clusters_and_cosine_identity():
    X, y = _clusters()
    e = IDLevelEncoder(11, D, 32, "minmax", seed=0).fit(X)
    H = e.encode(X)
    am = AssociativeMemory(4, D).fit(H, y)
    assert (am.predict(H) == y).mean() > 0.95
    S = am.scores(H[:5])
    manual = np.array([[cos(H[i], am.prototypes[k]) for k in range(4)] for i in range(5)])
    assert np.allclose(S, manual, atol=1e-6)
    Si = am.scores(H[:5], mode="integer")
    manual_i = np.array([[cos(H[i], am.acc[k]) for k in range(4)] for i in range(5)])
    assert np.allclose(Si, manual_i, atol=1e-9)


def test_am_accumulator_is_class_sum_and_retrain_not_worse_on_train():
    X, y = _clusters(seed=3)
    X = X + np.random.default_rng(9).normal(size=X.shape) * 2.5   # make it harder
    e = IDLevelEncoder(11, 4000, 16, "minmax", seed=1).fit(X)
    H = e.encode(X)
    am = AssociativeMemory(4, 4000).fit(H, y)
    assert np.array_equal(am.acc[2], H[y == 2].sum(0, dtype=np.int32))
    acc0 = (am.predict(H) == y).mean()
    for _ in range(10):
        am.retrain_epoch(H.astype(np.float32), y)
    assert (am.predict(H) == y).mean() >= acc0 - 0.02


# ---------- data splits / leakage ----------
@pytest.fixture(scope="module")
def white():
    X, y, _ = load_wine(ROOT / "data" / "winequality-white.csv")
    return X, y, group_duplicates(X, y)


@pytest.mark.parametrize("protocol", ["dedup", "nodedup"])
@pytest.mark.parametrize("seed", [0, 1, 2])
def test_split_no_leakage_all_classes_present(white, protocol, seed):
    X, y, g = white
    sp = make_split(y, g, seed, protocol)
    audit_split(X, y, g, sp, protocol, labels=sorted(np.unique(y).tolist()))   # raises on any violation


def test_split_deterministic_and_seed_sensitive(white):
    X, y, g = white
    a, b, c = make_split(y, g, 5, "dedup"), make_split(y, g, 5, "dedup"), make_split(y, g, 6, "dedup")
    assert np.array_equal(a.test, b.test) and not np.array_equal(a.test, c.test)


def test_dedup_sizes_and_nodedup_keeps_duplicates(white):
    X, y, g = white
    assert len(g.first_idx) == 3961 and len(y) == 4898
    d, n = make_split(y, g, 0, "dedup"), make_split(y, g, 0, "nodedup")
    assert len(d.train) + len(d.val) + len(d.test) == 3961
    assert len(n.train) + len(n.val) + len(n.test) == 4898


def test_audit_detects_injected_leak(white):
    X, y, g = white
    sp = make_split(y, g, 0, "dedup")
    from hdcmem.data import Split
    bad = Split(sp.train, sp.val, np.concatenate([sp.test, sp.train[:1]]))
    with pytest.raises(AssertionError):
        audit_split(X, y, g, bad, "dedup", labels=sorted(np.unique(y).tolist()))


def test_grouped3_mapping():
    assert to_task(np.array([3, 5, 6, 7, 9]), "grouped3").tolist() == [0, 0, 1, 2, 2]


def test_metrics_fixed_label_shape():
    m = evaluate([3, 4, 4, 5], [3, 4, 5, 5], labels=[3, 4, 5, 6])
    assert np.array(m["confusion_matrix"]).shape == (4, 4)
