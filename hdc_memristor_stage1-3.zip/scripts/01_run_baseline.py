"""Stages 1-3: software HDC baseline + conventional baselines. Writes results/stage1/raw_results.jsonl.
Usage: python scripts/01_run_baseline.py [--trials N] [--out DIR]"""
import argparse, json, platform, sys, time
from pathlib import Path
import numpy as np, yaml
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from hdcmem.data import load_wine, group_duplicates, make_split, audit_split, to_task
from hdcmem.hdc import IDLevelEncoder, AssociativeMemory
from hdcmem.metrics import evaluate, macro_f1
from hdcmem.baselines import grids, select_and_evaluate

ap = argparse.ArgumentParser()
ap.add_argument("--config", default=str(ROOT / "configs" / "experiment.yaml"))
ap.add_argument("--trials", type=int, default=None)
ap.add_argument("--out", default=str(ROOT / "results" / "stage1"))
args = ap.parse_args()
cfg = yaml.safe_load(open(args.config))
n_trials = args.trials or cfg["split"]["n_trials"]
OUT = Path(args.out); OUT.mkdir(parents=True, exist_ok=True)
ds = cfg["dataset"]["primary"]
X, y, feats = load_wine(ROOT / cfg["dataset"]["paths"][ds])
groups = group_duplicates(X, y)
U = X[groups.first_idx]
labels_by_task = {"original": sorted(np.unique(y).tolist()), "grouped3": [0, 1, 2]}
h = cfg["hdc"]; D = h["D"]


def run_hdc(split, hv_seed, ytask):
    """Model selection over (scaling, Q[, retrain epoch]) using validation macro-F1 only."""
    best = {(t, m): None for t in cfg["tasks"] for m in ("hdc_single", "hdc_retrain")}
    yidx = {t: {k: np.searchsorted(labels_by_task[t], ytask[t][r]) for k, r in
                (("tr", split.train), ("va", split.val), ("te", split.test))} for t in cfg["tasks"]}
    for scaling in h["scaling_grid"]:
        for Q in h["Q_grid"]:
            enc = IDLevelEncoder(X.shape[1], D, Q, scaling, hv_seed).fit(X[split.train])   # fit on TRAIN rows only
            HU = enc.encode(U)                                                           # encode each unique record once
            Htr, Hva, Hte = (HU[groups.inverse[r]].astype(np.float32) for r in (split.train, split.val, split.test))
            for t in cfg["tasks"]:
                labels = labels_by_task[t]; yi = yidx[t]
                am = AssociativeMemory(len(labels), D).fit(Htr, yi["tr"])
                for e in range(h["retrain_max_epochs"] + 1):
                    if e > 0:
                        am.retrain_epoch(Htr, yi["tr"])
                    v = macro_f1(yi["va"], am.predict(Hva), labels)
                    for m in (("hdc_single", "hdc_retrain") if e == 0 else ("hdc_retrain",)):
                        b = best[(t, m)]
                        if b is None or v > b["val_macro_f1"]:
                            pred = am.predict(Hte)
                            best[(t, m)] = {"model": m, "params": {"scaling": scaling, "Q": Q, "D": D, "epochs": e},
                                            "val_macro_f1": v, **evaluate(yi["te"], pred, list(range(len(labels))))}
    return best


audits, t0 = [], time.time()
with open(OUT / "raw_results.jsonl", "w") as fout:
    for protocol in cfg["split"]["protocols"]:
        for trial in range(n_trials):
            split = make_split(y, groups, cfg["split"]["split_seed_base"] + trial, protocol, tuple(cfg["split"]["fractions"]))
            audits.append({"trial": trial, **audit_split(X, y, groups, split, protocol, labels_by_task["original"])})
            ytask = {t: to_task(y, t) for t in cfg["tasks"]}
            hdc_best = run_hdc(split, cfg["split"]["hv_seed_base"] + trial, ytask)
            for t in cfg["tasks"]:
                labels = labels_by_task[t]
                recs = [hdc_best[(t, "hdc_single")], hdc_best[(t, "hdc_retrain")]]
                for name, grid in grids(cfg["baselines"]).items():
                    recs.append(select_and_evaluate(name, grid, X[split.train], ytask[t][split.train], X[split.val], ytask[t][split.val],
                                                    X[split.test], ytask[t][split.test], labels, trial, cfg["baselines"]["rf_trees"]))
                for r in recs:
                    r.update(dataset=ds, protocol=protocol, task=t, trial=trial, labels=labels, n_test=int(len(split.test)))
                    fout.write(json.dumps(r) + "\n")
            fout.flush()
            print(f"[{time.time()-t0:6.0f}s] {protocol} trial {trial} done", flush=True)
(OUT / "split_audit.json").write_text(json.dumps(audits, indent=1))
(OUT / "environment.json").write_text(json.dumps({"python": platform.python_version(), "numpy": np.__version__,
    "platform": platform.platform(), "cpu_count": __import__("os").cpu_count(), "config": cfg}, indent=1))
print("all splits passed the leakage audit")
