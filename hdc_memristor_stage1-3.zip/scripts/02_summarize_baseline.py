"""Aggregate raw_results.jsonl -> tables (md/csv) and figures. Mean, sample std (ddof=1), 95% Student-t CI over trials."""
import json, sys
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats
ROOT = Path(__file__).resolve().parents[1]
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "results" / "stage1"
rows = [json.loads(l) for l in open(OUT / "raw_results.jsonl")]
df = pd.DataFrame(rows)
METRICS = ["accuracy", "macro_f1", "balanced_accuracy", "mean_abs_label_error"]
ORDER = ["majority", "centroid", "logreg", "knn", "rf", "hdc_single", "hdc_retrain"]
NAMES = {"majority": "Majority class", "centroid": "Nearest centroid (std. features)", "logreg": "Logistic regression",
         "knn": "k-NN", "rf": "Random forest", "hdc_single": "HDC single-pass (binary AM)", "hdc_retrain": "HDC + retraining (binary AM)"}


def ci(x, conf=0.95):
    x = np.asarray(x, float); n = len(x)
    m, s = x.mean(), x.std(ddof=1) if n > 1 else 0.0
    h = stats.t.ppf(0.5 + conf / 2, n - 1) * s / np.sqrt(n) if n > 1 else 0.0
    return m, s, m - h, m + h


summ = []
for (proto, task, model), g in df.groupby(["protocol", "task", "model"]):
    r = {"protocol": proto, "task": task, "model": model, "n_trials": len(g)}
    for m in METRICS:
        mean, sd, lo, hi = ci(g[m]); r.update({f"{m}_mean": mean, f"{m}_std": sd, f"{m}_ci_lo": lo, f"{m}_ci_hi": hi})
    summ.append(r)
S = pd.DataFrame(summ); S["o"] = S.model.map(ORDER.index); S = S.sort_values(["protocol", "task", "o"]).drop(columns="o")
S.to_csv(OUT / "summary_table.csv", index=False)

md = ["# Stage 1-3 results: software baselines [SW] (white wine; test set; mean ± std over trials, [95% t-CI])\n",
      "All numbers are measured on held-out test rows of repeated stratified splits. Nothing here is a hardware result.\n"]
for proto in S.protocol.unique():
    for task in S.task.unique():
        md += [f"## protocol = {proto}, task = {task}\n", "| model | accuracy | macro-F1 | balanced acc. | mean abs label error |", "|---|---|---|---|---|"]
        for _, r in S[(S.protocol == proto) & (S.task == task)].iterrows():
            f = lambda m: f"{r[m+'_mean']:.3f} ± {r[m+'_std']:.3f} [{r[m+'_ci_lo']:.3f}, {r[m+'_ci_hi']:.3f}]"
            md.append(f"| {NAMES[r.model]} | {f('accuracy')} | {f('macro_f1')} | {f('balanced_accuracy')} | {r['mean_abs_label_error_mean']:.3f} ± {r['mean_abs_label_error_std']:.3f} |")
        md.append("")

# paired differences in macro-F1 (same trial = same split)
md += ["## Paired macro-F1 differences (HDC minus model; same splits; mean [95% t-CI]; positive favours HDC)\n",
       "| protocol | task | HDC variant | vs | mean diff | 95% CI | HDC better in k/n trials |", "|---|---|---|---|---|---|---|"]
for (proto, task), g in df.groupby(["protocol", "task"]):
    P = g.pivot(index="trial", columns="model", values="macro_f1")
    for hv in ("hdc_single", "hdc_retrain"):
        for other in ORDER:
            if other == hv or other.startswith("hdc"): continue
            d = (P[hv] - P[other]).values; m, s, lo, hi = ci(d)
            md.append(f"| {proto} | {task} | {NAMES[hv]} | {NAMES[other]} | {m:+.3f} | [{lo:+.3f}, {hi:+.3f}] | {(d>0).sum()}/{len(d)} |")
md.append("")

# selected hyper-parameters
md += ["## Hyper-parameters selected on validation (HDC)\n"]
for (proto, task, model), g in df[df.model.str.startswith("hdc")].groupby(["protocol", "task", "model"]):
    p = pd.DataFrame(list(g.params))
    md.append(f"- {proto}/{task}/{model}: scaling {p.scaling.value_counts().to_dict()}, Q {p.Q.value_counts().sort_index().to_dict()}, "
              f"epochs median {int(p.epochs.median())} (range {p.epochs.min()}-{p.epochs.max()})")
md.append("")

# split audit
aud = json.load(open(OUT / "split_audit.json")); md += ["## Split audit (all passed: zero exact-record overlap, every class in every split)\n",
      "| protocol | train n | val n | test n | min class count in val | min class count in test |", "|---|---|---|---|---|---|"]
for proto in sorted({a["protocol"] for a in aud}):
    A = [a for a in aud if a["protocol"] == proto]
    mn = lambda k: min(min(a[k]["class_counts"].values()) for a in A)
    md.append(f"| {proto} | {np.mean([a['train']['n'] for a in A]):.0f} | {np.mean([a['val']['n'] for a in A]):.0f} | {np.mean([a['test']['n'] for a in A]):.0f} | {mn('val')} | {mn('test')} |")
(OUT / "summary.md").write_text("\n".join(md)); print("\n".join(md))

# ---- figures ----
fig, axes = plt.subplots(2, 2, figsize=(13, 7.5), sharey="row")
for i, task in enumerate(["original", "grouped3"]):
    for j, proto in enumerate(["dedup", "nodedup"]):
        ax = axes[i, j]; s = S[(S.protocol == proto) & (S.task == task)].set_index("model").loc[ORDER]
        mu = s.macro_f1_mean.values; err = np.vstack([mu - s.macro_f1_ci_lo.values, s.macro_f1_ci_hi.values - mu])
        ax.bar(range(len(ORDER)), mu, yerr=err, capsize=3, color=["#999"] * 5 + ["#1f77b4", "#ff7f0e"])
        ax.set_xticks(range(len(ORDER))); ax.set_xticklabels(["majority", "centroid", "logreg", "kNN", "RF", "HDC\nsingle", "HDC\nretrain"], fontsize=8)
        ax.set_title(f"{task} labels, {proto}", fontsize=10); ax.set_ylabel("test macro-F1" if j == 0 else "")
fig.suptitle("Software baselines [SW], white wine: test macro-F1, mean with 95% CI over trials", fontsize=11); fig.tight_layout()
fig.savefig(OUT / "fig_macro_f1_baselines.png", dpi=160); plt.close(fig)

for task in ["original", "grouped3"]:
    g = df[(df.protocol == "dedup") & (df.task == task)]; labels = g.labels.iloc[0]
    best_b = S[(S.protocol == "dedup") & (S.task == task) & (~S.model.str.startswith("hdc")) & (S.model != "majority")].sort_values("macro_f1_mean").model.iloc[-1]
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.6))
    for ax, model in zip(axes, ["hdc_single", "hdc_retrain", best_b]):
        cm = np.sum([np.array(c) for c in g[g.model == model].confusion_matrix], axis=0).astype(float)
        cmn = cm / cm.sum(1, keepdims=True)
        ax.imshow(cmn, vmin=0, vmax=1, cmap="Blues")
        for a in range(len(labels)):
            for b in range(len(labels)):
                ax.text(b, a, f"{cmn[a,b]:.2f}\n({int(cm[a,b])})", ha="center", va="center", fontsize=7, color="white" if cmn[a, b] > .6 else "black")
        tick_labels = [str(l) for l in (labels if task == "original" else ["<=5", "6", ">=7"])]
        ax.set_xticks(range(len(labels))); ax.set_xticklabels(tick_labels); ax.set_yticks(range(len(labels))); ax.set_yticklabels(tick_labels)
        ax.set_xlabel("predicted"); ax.set_ylabel("true"); ax.set_title(NAMES[model], fontsize=9)
    fig.suptitle(f"Test confusion matrices summed over trials (row-normalised; counts in brackets) [SW], dedup, {task}", fontsize=10)
    fig.tight_layout(); fig.savefig(OUT / f"fig_confusion_{task}_dedup.png", dpi=160); plt.close(fig)
print("figures written")
