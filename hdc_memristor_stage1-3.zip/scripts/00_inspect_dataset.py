"""Stage 0: dataset inspection. Writes results/stage0/dataset_report.{json,md}. No modelling here."""
import json
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results" / "stage0"; OUT.mkdir(parents=True, exist_ok=True)
FILES = {"red": ROOT/"data"/"winequality-red.csv", "white": ROOT/"data"/"winequality-white.csv"}
TARGET = "quality"

report, md = {}, ["# Stage 0 - Dataset inspection (software; computed from the uploaded CSVs)\n"]
for name, path in FILES.items():
    df = pd.read_csv(path, sep=";")
    feats = [c for c in df.columns if c != TARGET]
    dist = df[TARGET].value_counts().sort_index()
    n_dup = int(df.duplicated().sum())
    uniq = df.drop_duplicates()
    conflicts = int(uniq.duplicated(subset=feats, keep=False).sum())
    report[name] = dict(
        n_samples=len(df), n_features=len(feats), features=feats, target=TARGET,
        missing_total=int(df.isna().sum().sum()), missing_per_col={k:int(v) for k,v in df.isna().sum().items()},
        dtypes={c: str(t) for c, t in df.dtypes.items()},
        class_counts={int(k): int(v) for k, v in dist.items()},
        class_fraction={int(k): round(float(v)/len(df), 4) for k, v in dist.items()},
        n_exact_duplicate_rows=n_dup, n_unique_rows=len(uniq),
        class_counts_after_dedup={int(k): int(v) for k, v in uniq[TARGET].value_counts().sort_index().items()},
        rows_with_identical_features_but_different_labels=conflicts,
        feature_min={k: float(v) for k, v in df[feats].min().items()},
        feature_max={k: float(v) for k, v in df[feats].max().items()},
        feature_skew={c: round(float(v), 3) for c, v in df[feats].skew().items()},
    )
    md += [f"## {name} wine", f"- samples: **{len(df)}**, input features: **{len(feats)}**, target: `{TARGET}` (integer sensory score)",
           f"- missing values (total): **{report[name]['missing_total']}**",
           f"- exact duplicate rows: **{n_dup}** ({n_dup/len(df):.1%}) -> {len(uniq)} unique rows",
           f"- rows sharing identical features but different labels (after exact dedup): {conflicts}",
           "", "| quality | count | fraction | count after dedup |", "|---|---|---|---|"]
    for k, v in dist.items():
        md.append(f"| {k} | {v} | {v/len(df):.3f} | {report[name]['class_counts_after_dedup'].get(int(k),0)} |")
    md += ["", "Features (min, max, skew):", ""]
    for c in feats:
        md.append(f"- {c}: {df[c].min():g}, {df[c].max():g}, skew {df[c].skew():.2f}")
    md.append("")
(OUT/"dataset_report.json").write_text(json.dumps(report, indent=2))
(OUT/"dataset_report.md").write_text("\n".join(md))
print("\n".join(md))
