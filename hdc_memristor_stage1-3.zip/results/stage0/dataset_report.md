# Stage 0 - Dataset inspection (software; computed from the uploaded CSVs)

## red wine
- samples: **1599**, input features: **11**, target: `quality` (integer sensory score)
- missing values (total): **0**
- exact duplicate rows: **240** (15.0%) -> 1359 unique rows
- rows sharing identical features but different labels (after exact dedup): 0

| quality | count | fraction | count after dedup |
|---|---|---|---|
| 3 | 10 | 0.006 | 10 |
| 4 | 53 | 0.033 | 53 |
| 5 | 681 | 0.426 | 577 |
| 6 | 638 | 0.399 | 535 |
| 7 | 199 | 0.124 | 167 |
| 8 | 18 | 0.011 | 17 |

Features (min, max, skew):

- fixed acidity: 4.6, 15.9, skew 0.98
- volatile acidity: 0.12, 1.58, skew 0.67
- citric acid: 0, 1, skew 0.32
- residual sugar: 0.9, 15.5, skew 4.54
- chlorides: 0.012, 0.611, skew 5.68
- free sulfur dioxide: 1, 72, skew 1.25
- total sulfur dioxide: 6, 289, skew 1.52
- density: 0.99007, 1.00369, skew 0.07
- pH: 2.74, 4.01, skew 0.19
- sulphates: 0.33, 2, skew 2.43
- alcohol: 8.4, 14.9, skew 0.86

## white wine
- samples: **4898**, input features: **11**, target: `quality` (integer sensory score)
- missing values (total): **0**
- exact duplicate rows: **937** (19.1%) -> 3961 unique rows
- rows sharing identical features but different labels (after exact dedup): 0

| quality | count | fraction | count after dedup |
|---|---|---|---|
| 3 | 20 | 0.004 | 20 |
| 4 | 163 | 0.033 | 153 |
| 5 | 1457 | 0.297 | 1175 |
| 6 | 2198 | 0.449 | 1788 |
| 7 | 880 | 0.180 | 689 |
| 8 | 175 | 0.036 | 131 |
| 9 | 5 | 0.001 | 5 |

Features (min, max, skew):

- fixed acidity: 3.8, 14.2, skew 0.65
- volatile acidity: 0.08, 1.1, skew 1.58
- citric acid: 0, 1.66, skew 1.28
- residual sugar: 0.6, 65.8, skew 1.08
- chlorides: 0.009, 0.346, skew 5.02
- free sulfur dioxide: 2, 289, skew 1.41
- total sulfur dioxide: 9, 440, skew 0.39
- density: 0.98711, 1.03898, skew 0.98
- pH: 2.72, 3.82, skew 0.46
- sulphates: 0.22, 1.08, skew 0.98
- alcohol: 8, 14.2, skew 0.49
