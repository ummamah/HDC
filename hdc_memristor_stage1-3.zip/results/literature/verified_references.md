# Literature ledger (working document, NOT a related-work section)
Status as of Stage 1-3. "Verified" = title, authors, venue and DOI were read on the publisher/PubMed/arXiv/author-PDF page during this session.
Nothing below supports a novelty claim yet; a gap statement is deferred until the experiments are complete.

## Verified
1. Pizarro K., Vourkas I. Design and Simulation of a Hyperdimensional Computing System with Memristive Associative Memory for Image Classification. Int. J. Unconventional Computing 19(2-3):219-244, 2024. DOI 10.32908/ijuc.v19.120824. (full text read)
   - Facts read: 19x19 binary digit images (6260 samples), D=1000, MATLAB behavioural memristor model (Pershin-Di Ventra threshold model), perceptron-style memristive AM with 2/4/6 inputs, variability of SET/RESET thresholds and R_ON, accuracy-only reporting, memristive AM did not exceed software HDC. Abstract-level: circuit-level behavioural simulation, no physical devices.
2. Karunaratne G. et al. In-memory hyperdimensional computing. Nature Electronics 3:327-337, 2020. DOI 10.1038/s41928-020-0410-3. (abstract + first page read) PCM, 760,000 devices, experimental, language/news/EMG tasks.
3. Kazemi A. et al. Achieving software-equivalent accuracy for hyperdimensional computing with ferroelectric-based in-memory computing. Scientific Reports 12:19201, 2022. DOI 10.1038/s41598-022-23116-w. (abstract read) Multi-bit FeFET IMC; studies device/circuit/architecture non-idealities.
4. Huang Y. et al. Hyperdimensional in-memory computing with analogue memristive crossbar arrays. Nature Communications 17(1):9162, 2026. DOI 10.1038/s41467-026-76067-5. (PubMed record + abstract + figure legends read) Language ID on a memristive SoC; single-layer perceptron outperforms cosine-similarity AM in simulation at similar hardware cost.
5. Kanerva P. Hyperdimensional computing: an introduction to computing in distributed representation with high-dimensional random vectors. Cognitive Computation 1:139-159, 2009. DOI 10.1007/s12559-009-9009-8. (first page read)
6. Kleyko D., Rachkovskij D.A., Osipov E., Rahimi A. A survey on hyperdimensional computing aka vector symbolic architectures, Part I: models and data transformations. ACM Computing Surveys, 2022. DOI 10.1145/3538531. (volume/pages not checked)
7. Kleyko D., Rachkovskij D.A., Osipov E., Rahimi A. ... Part II: applications, cognitive models, and challenges. ACM Computing Surveys 55(9), 2023. DOI 10.1145/3558000.
8. Thomas A., Dasgupta S., Rosing T. A theoretical perspective on hyperdimensional computing. J. Artificial Intelligence Research 72:215-249, 2021. DOI 10.1613/jair.1.12664.
9. Cortez P. et al. Modeling wine preferences by data mining from physicochemical properties. Decision Support Systems 47(4):547-553, 2009. DOI 10.1016/j.dss.2009.05.016. (taken from the dataset's own winequality.names citation request; publisher page not opened)

## Found in searches but NOT yet verified (do not cite until checked)
- DistHD (arXiv 2304.05503), MIMHD (arXiv 2106.12029), HyDREA (ACM DOI 10.1145/3524067 seen in a search snippet), LogHD (arXiv 2511.03938): HDC bit-flip / precision / analogue-noise robustness. Published venues and exact claims still to be read.
- Ge L., Parhi K.K. Classification using hyperdimensional computing: a review. IEEE Circuits Syst. Mag. 2020 (cited in Pizarro & Vourkas ref list; DOI not yet checked).
- Wu T.F. et al. ISSCC 2018 (HDC on CNFET + RRAM) (cited in Pizarro & Vourkas; not yet checked).
- Prior HDC work on tabular / wine-quality data: no search done yet.
