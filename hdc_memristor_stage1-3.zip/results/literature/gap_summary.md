# Prior work and tentative research gap (concise; literature search paused)

## What existing work does (verified by reading the source page; see verified_references.md)
- Karunaratne 2020 (Nat. Electron., PCM): experimental in-memory HDC, language/news/EMG tasks.
- Pizarro & Vourkas 2024 (IJUC): simulated memristive perceptron-style AM, 19x19 binary digit images, D=1000, threshold/R_ON variability, accuracy only; did not exceed software HDC.
- Kazemi 2022 (Sci. Rep., FeFET): multi-bit IMC for HDC; studies device/circuit/architecture non-idealities.
- Huang 2026 (Nat. Commun.): memristive SoC language ID; perceptron beats cosine-similarity AM in simulation.
- Thomas/Dasgupta/Rosing 2021 (JAIR): theory of HDC, including noise tolerance.

## Tentative gap (HYPOTHESIS, not a claim)
Reviewed work uses tasks with high software accuracy (language, digits, EMG). I found no verified study of memristive/analogue HDC associative-memory degradation on a low-margin, imbalanced, ordinal tabular task with macro-F1 / balanced accuracy and a margin-based explanation of the loss.

## Uncertain / unchecked
- Search was not exhaustive; absence of such a study is NOT established.
- Bit-flip/precision papers (DistHD, MIMHD, HyDREA, LogHD) seen only as snippets: unread, uncited. They may already cover precision-vs-robustness trade-offs.
- Ge & Parhi 2020 review and Wu 2018 ISSCC: DOIs unchecked. No search yet for HDC on tabular/wine data.
- Pizarro & Vourkas is assumed to be the paper in the user's manuscript (manuscript not seen).
