# Stage 1-3 results: software baselines [SW] (white wine; test set; mean ± std over trials, [95% t-CI])

All numbers are measured on held-out test rows of repeated stratified splits. Nothing here is a hardware result.

## protocol = dedup, task = grouped3

| model | accuracy | macro-F1 | balanced acc. | mean abs label error |
|---|---|---|---|---|
| Majority class | 0.451 ± 0.000 [0.451, 0.451] | 0.207 ± 0.000 [0.207, 0.207] | 0.333 ± 0.000 [0.333, 0.333] | 0.549 ± 0.000 |
| Nearest centroid (std. features) | 0.497 ± 0.014 [0.487, 0.507] | 0.494 ± 0.014 [0.484, 0.505] | 0.546 ± 0.012 [0.537, 0.555] | 0.580 ± 0.018 |
| Logistic regression | 0.560 ± 0.024 [0.542, 0.577] | 0.546 ± 0.019 [0.532, 0.559] | 0.549 ± 0.024 [0.532, 0.566] | 0.466 ± 0.037 |
| k-NN | 0.580 ± 0.015 [0.569, 0.591] | 0.561 ± 0.016 [0.550, 0.572] | 0.550 ± 0.016 [0.538, 0.561] | 0.440 ± 0.019 |
| Random forest | 0.604 ± 0.016 [0.593, 0.616] | 0.593 ± 0.012 [0.584, 0.601] | 0.585 ± 0.012 [0.577, 0.593] | 0.413 ± 0.019 |
| HDC single-pass (binary AM) | 0.500 ± 0.017 [0.488, 0.512] | 0.498 ± 0.018 [0.485, 0.511] | 0.542 ± 0.018 [0.529, 0.555] | 0.568 ± 0.021 |
| HDC + retraining (binary AM) | 0.529 ± 0.020 [0.515, 0.544] | 0.523 ± 0.013 [0.514, 0.532] | 0.530 ± 0.013 [0.520, 0.539] | 0.512 ± 0.024 |

## protocol = dedup, task = original

| model | accuracy | macro-F1 | balanced acc. | mean abs label error |
|---|---|---|---|---|
| Majority class | 0.451 ± 0.000 [0.451, 0.451] | 0.089 ± 0.000 [0.089, 0.089] | 0.143 ± 0.000 [0.143, 0.143] | 0.633 ± 0.000 |
| Nearest centroid (std. features) | 0.310 ± 0.016 [0.298, 0.321] | 0.212 ± 0.010 [0.205, 0.218] | 0.308 ± 0.057 [0.268, 0.349] | 1.104 ± 0.036 |
| Logistic regression | 0.411 ± 0.107 [0.335, 0.488] | 0.239 ± 0.033 [0.215, 0.262] | 0.289 ± 0.065 [0.243, 0.336] | 0.850 ± 0.280 |
| k-NN | 0.498 ± 0.022 [0.482, 0.514] | 0.277 ± 0.031 [0.255, 0.299] | 0.269 ± 0.025 [0.251, 0.287] | 0.599 ± 0.037 |
| Random forest | 0.546 ± 0.014 [0.536, 0.557] | 0.317 ± 0.026 [0.298, 0.335] | 0.302 ± 0.020 [0.288, 0.316] | 0.512 ± 0.019 |
| HDC single-pass (binary AM) | 0.344 ± 0.016 [0.333, 0.355] | 0.215 ± 0.014 [0.205, 0.225] | 0.270 ± 0.033 [0.246, 0.293] | 0.942 ± 0.035 |
| HDC + retraining (binary AM) | 0.416 ± 0.039 [0.388, 0.444] | 0.205 ± 0.025 [0.186, 0.223] | 0.224 ± 0.017 [0.212, 0.236] | 0.708 ± 0.064 |

## protocol = nodedup, task = grouped3

| model | accuracy | macro-F1 | balanced acc. | mean abs label error |
|---|---|---|---|---|
| Majority class | 0.450 ± 0.006 [0.446, 0.455] | 0.207 ± 0.002 [0.205, 0.208] | 0.333 ± 0.000 [0.333, 0.333] | 0.550 ± 0.006 |
| Nearest centroid (std. features) | 0.481 ± 0.017 [0.469, 0.494] | 0.477 ± 0.018 [0.464, 0.490] | 0.532 ± 0.015 [0.521, 0.542] | 0.609 ± 0.020 |
| Logistic regression | 0.559 ± 0.024 [0.542, 0.576] | 0.537 ± 0.017 [0.525, 0.549] | 0.534 ± 0.017 [0.522, 0.547] | 0.468 ± 0.041 |
| k-NN | 0.571 ± 0.016 [0.559, 0.582] | 0.557 ± 0.019 [0.543, 0.570] | 0.550 ± 0.018 [0.537, 0.562] | 0.456 ± 0.021 |
| Random forest | 0.602 ± 0.016 [0.591, 0.613] | 0.589 ± 0.019 [0.575, 0.603] | 0.581 ± 0.022 [0.564, 0.597] | 0.416 ± 0.017 |
| HDC single-pass (binary AM) | 0.485 ± 0.012 [0.476, 0.494] | 0.481 ± 0.013 [0.472, 0.490] | 0.530 ± 0.015 [0.519, 0.541] | 0.593 ± 0.015 |
| HDC + retraining (binary AM) | 0.510 ± 0.042 [0.480, 0.540] | 0.498 ± 0.037 [0.472, 0.524] | 0.506 ± 0.029 [0.485, 0.527] | 0.533 ± 0.056 |

## protocol = nodedup, task = original

| model | accuracy | macro-F1 | balanced acc. | mean abs label error |
|---|---|---|---|---|
| Majority class | 0.450 ± 0.006 [0.446, 0.455] | 0.089 ± 0.001 [0.088, 0.089] | 0.143 ± 0.000 [0.143, 0.143] | 0.630 ± 0.010 |
| Nearest centroid (std. features) | 0.297 ± 0.018 [0.284, 0.310] | 0.202 ± 0.011 [0.193, 0.210] | 0.303 ± 0.058 [0.262, 0.344] | 1.139 ± 0.042 |
| Logistic regression | 0.451 ± 0.107 [0.375, 0.528] | 0.236 ± 0.032 [0.213, 0.258] | 0.273 ± 0.070 [0.223, 0.324] | 0.751 ± 0.289 |
| k-NN | 0.496 ± 0.019 [0.483, 0.510] | 0.267 ± 0.034 [0.243, 0.291] | 0.261 ± 0.028 [0.241, 0.282] | 0.598 ± 0.035 |
| Random forest | 0.546 ± 0.011 [0.538, 0.554] | 0.305 ± 0.019 [0.291, 0.319] | 0.292 ± 0.017 [0.280, 0.304] | 0.508 ± 0.012 |
| HDC single-pass (binary AM) | 0.343 ± 0.015 [0.332, 0.353] | 0.212 ± 0.011 [0.204, 0.220] | 0.281 ± 0.047 [0.247, 0.314] | 0.949 ± 0.032 |
| HDC + retraining (binary AM) | 0.408 ± 0.026 [0.390, 0.426] | 0.180 ± 0.022 [0.165, 0.196] | 0.195 ± 0.019 [0.182, 0.209] | 0.741 ± 0.057 |

## Paired macro-F1 differences (HDC minus model; same splits; mean [95% t-CI]; positive favours HDC)

| protocol | task | HDC variant | vs | mean diff | 95% CI | HDC better in k/n trials |
|---|---|---|---|---|---|---|
| dedup | grouped3 | HDC single-pass (binary AM) | Majority class | +0.290 | [+0.277, +0.303] | 10/10 |
| dedup | grouped3 | HDC single-pass (binary AM) | Nearest centroid (std. features) | +0.003 | [-0.007, +0.014] | 5/10 |
| dedup | grouped3 | HDC single-pass (binary AM) | Logistic regression | -0.048 | [-0.063, -0.033] | 0/10 |
| dedup | grouped3 | HDC single-pass (binary AM) | k-NN | -0.063 | [-0.077, -0.049] | 0/10 |
| dedup | grouped3 | HDC single-pass (binary AM) | Random forest | -0.095 | [-0.111, -0.079] | 0/10 |
| dedup | grouped3 | HDC + retraining (binary AM) | Majority class | +0.316 | [+0.306, +0.325] | 10/10 |
| dedup | grouped3 | HDC + retraining (binary AM) | Nearest centroid (std. features) | +0.029 | [+0.017, +0.040] | 10/10 |
| dedup | grouped3 | HDC + retraining (binary AM) | Logistic regression | -0.023 | [-0.034, -0.011] | 1/10 |
| dedup | grouped3 | HDC + retraining (binary AM) | k-NN | -0.038 | [-0.052, -0.024] | 0/10 |
| dedup | grouped3 | HDC + retraining (binary AM) | Random forest | -0.070 | [-0.081, -0.058] | 0/10 |
| dedup | original | HDC single-pass (binary AM) | Majority class | +0.126 | [+0.116, +0.137] | 10/10 |
| dedup | original | HDC single-pass (binary AM) | Nearest centroid (std. features) | +0.004 | [-0.009, +0.016] | 6/10 |
| dedup | original | HDC single-pass (binary AM) | Logistic regression | -0.023 | [-0.049, +0.003] | 3/10 |
| dedup | original | HDC single-pass (binary AM) | k-NN | -0.062 | [-0.087, -0.036] | 0/10 |
| dedup | original | HDC single-pass (binary AM) | Random forest | -0.101 | [-0.122, -0.081] | 0/10 |
| dedup | original | HDC + retraining (binary AM) | Majority class | +0.116 | [+0.098, +0.134] | 10/10 |
| dedup | original | HDC + retraining (binary AM) | Nearest centroid (std. features) | -0.007 | [-0.025, +0.011] | 4/10 |
| dedup | original | HDC + retraining (binary AM) | Logistic regression | -0.034 | [-0.055, -0.013] | 0/10 |
| dedup | original | HDC + retraining (binary AM) | k-NN | -0.072 | [-0.091, -0.054] | 0/10 |
| dedup | original | HDC + retraining (binary AM) | Random forest | -0.112 | [-0.132, -0.093] | 0/10 |
| nodedup | grouped3 | HDC single-pass (binary AM) | Majority class | +0.274 | [+0.265, +0.284] | 10/10 |
| nodedup | grouped3 | HDC single-pass (binary AM) | Nearest centroid (std. features) | +0.005 | [-0.007, +0.017] | 6/10 |
| nodedup | grouped3 | HDC single-pass (binary AM) | Logistic regression | -0.056 | [-0.070, -0.041] | 0/10 |
| nodedup | grouped3 | HDC single-pass (binary AM) | k-NN | -0.075 | [-0.091, -0.060] | 0/10 |
| nodedup | grouped3 | HDC single-pass (binary AM) | Random forest | -0.108 | [-0.123, -0.092] | 0/10 |
| nodedup | grouped3 | HDC + retraining (binary AM) | Majority class | +0.291 | [+0.265, +0.318] | 10/10 |
| nodedup | grouped3 | HDC + retraining (binary AM) | Nearest centroid (std. features) | +0.022 | [-0.009, +0.053] | 7/10 |
| nodedup | grouped3 | HDC + retraining (binary AM) | Logistic regression | -0.039 | [-0.059, -0.019] | 1/10 |
| nodedup | grouped3 | HDC + retraining (binary AM) | k-NN | -0.058 | [-0.086, -0.031] | 2/10 |
| nodedup | grouped3 | HDC + retraining (binary AM) | Random forest | -0.091 | [-0.116, -0.065] | 0/10 |
| nodedup | original | HDC single-pass (binary AM) | Majority class | +0.123 | [+0.115, +0.131] | 10/10 |
| nodedup | original | HDC single-pass (binary AM) | Nearest centroid (std. features) | +0.010 | [+0.003, +0.018] | 9/10 |
| nodedup | original | HDC single-pass (binary AM) | Logistic regression | -0.024 | [-0.050, +0.003] | 3/10 |
| nodedup | original | HDC single-pass (binary AM) | k-NN | -0.055 | [-0.081, -0.028] | 0/10 |
| nodedup | original | HDC single-pass (binary AM) | Random forest | -0.093 | [-0.109, -0.077] | 0/10 |
| nodedup | original | HDC + retraining (binary AM) | Majority class | +0.092 | [+0.076, +0.107] | 10/10 |
| nodedup | original | HDC + retraining (binary AM) | Nearest centroid (std. features) | -0.021 | [-0.038, -0.004] | 2/10 |
| nodedup | original | HDC + retraining (binary AM) | Logistic regression | -0.055 | [-0.083, -0.027] | 1/10 |
| nodedup | original | HDC + retraining (binary AM) | k-NN | -0.086 | [-0.117, -0.056] | 0/10 |
| nodedup | original | HDC + retraining (binary AM) | Random forest | -0.125 | [-0.145, -0.104] | 0/10 |

## Hyper-parameters selected on validation (HDC)

- dedup/grouped3/hdc_retrain: scaling {'minmax': 5, 'quantile': 5}, Q {8: 2, 16: 3, 32: 2, 64: 3}, epochs median 5 (range 3-17)
- dedup/grouped3/hdc_single: scaling {'minmax': 9, 'quantile': 1}, Q {16: 5, 32: 3, 64: 2}, epochs median 0 (range 0-0)
- dedup/original/hdc_retrain: scaling {'minmax': 7, 'quantile': 3}, Q {16: 1, 32: 6, 64: 3}, epochs median 12 (range 7-19)
- dedup/original/hdc_single: scaling {'minmax': 6, 'quantile': 4}, Q {8: 1, 16: 3, 32: 5, 64: 1}, epochs median 0 (range 0-0)
- nodedup/grouped3/hdc_retrain: scaling {'minmax': 5, 'quantile': 5}, Q {8: 3, 16: 4, 32: 2, 64: 1}, epochs median 4 (range 0-19)
- nodedup/grouped3/hdc_single: scaling {'minmax': 7, 'quantile': 3}, Q {8: 2, 16: 2, 32: 3, 64: 3}, epochs median 0 (range 0-0)
- nodedup/original/hdc_retrain: scaling {'minmax': 7, 'quantile': 3}, Q {8: 2, 16: 3, 32: 2, 64: 3}, epochs median 9 (range 3-19)
- nodedup/original/hdc_single: scaling {'minmax': 6, 'quantile': 4}, Q {8: 2, 16: 3, 32: 3, 64: 2}, epochs median 0 (range 0-0)

## Split audit (all passed: zero exact-record overlap, every class in every split)

| protocol | train n | val n | test n | min class count in val | min class count in test |
|---|---|---|---|---|---|
| dedup | 2376 | 792 | 793 | 1 | 1 |
| nodedup | 2943 | 974 | 980 | 1 | 1 |