# Progress (Stages 0-3 complete; memristor model NOT started)
Run: pip install -r requirements.txt; pytest tests; python scripts/00_inspect_dataset.py; python scripts/01_run_baseline.py; python scripts/02_summarize_baseline.py
Files: configs/experiment.yaml, requirements.txt, src/hdcmem/{data,hdc,metrics,baselines}.py, tests/test_hdc.py,
scripts/{00_inspect_dataset,01_run_baseline,02_summarize_baseline}.py, results/stage0/*, results/stage1/{raw_results.jsonl,summary.md,summary_table.csv,split_audit.json,environment.json,pytest_report.txt,fig_*.png}, results/literature/*
Not done: memristor mapping, non-ideality sweeps, memory/latency measurement, other datasets, red-wine run, paper.
Known limitations: rare classes have 1-2 test samples/split; retraining chosen by val macro-F1 lowers balanced accuracy on original labels; trial CIs are resampling variability only.
