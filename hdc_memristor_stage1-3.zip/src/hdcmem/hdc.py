"""Bipolar HDC primitives: ID-level encoder and class-prototype associative memory (ideal software model)."""
from __future__ import annotations
import numpy as np


def random_bipolar(rng, shape):
    return (rng.integers(0, 2, size=shape, dtype=np.int8) * 2 - 1).astype(np.int8)


def make_level_hvs(rng, Q: int, D: int):
    """Q correlated level hypervectors. Level 0 is random; going to level q flips a further slice of a fixed random
    set of D/2 positions, so cos(L_0, L_q) = 1 - 2*flipped_q/D falls linearly and cos(L_0, L_{Q-1}) = 0 exactly."""
    if D % 2:
        raise ValueError("D must be even")
    base = random_bipolar(rng, (D,))
    flip = rng.permutation(D)[: D // 2]
    chunks = np.array_split(flip, Q - 1)
    L = np.empty((Q, D), dtype=np.int8)
    L[0] = base
    cur = base.copy()
    for q in range(1, Q):
        cur = cur.copy()
        cur[chunks[q - 1]] *= -1
        L[q] = cur
    return L


def bind(a, b):                      # elementwise product; self-inverse for bipolar vectors
    return (a * b).astype(np.int8)


def sign_tiebreak(s):                # bundling threshold; ties (sum == 0) -> +1 (deterministic)
    return np.where(s >= 0, 1, -1).astype(np.int8)


class UnitScaler:
    """Maps each feature to [0,1]. Parameters are learned ONLY by fit() on the training rows."""

    def __init__(self, kind: str):
        assert kind in ("minmax", "quantile")
        self.kind = kind

    def fit(self, X):
        if self.kind == "minmax":
            self.lo, hi = X.min(0), X.max(0)
            self.span = np.where(hi > self.lo, hi - self.lo, 1.0)
        else:
            self.sorted = np.sort(X, axis=0)       # empirical CDF of the training data
        return self

    def transform(self, X):
        if self.kind == "minmax":
            return np.clip((X - self.lo) / self.span, 0.0, 1.0)
        n = self.sorted.shape[0]
        u = np.empty_like(X, dtype=np.float64)
        for f in range(X.shape[1]):
            s = self.sorted[:, f]
            u[:, f] = (np.searchsorted(s, X[:, f], "left") + np.searchsorted(s, X[:, f], "right")) / (2.0 * n)
        return u


class IDLevelEncoder:
    """h(x) = sign( sum_f  ID_f (*) L_{q(x_f)} ),  (*) = elementwise binding, sum = bundling."""

    def __init__(self, n_features: int, D: int, Q: int, scaling: str, seed: int):
        rng = np.random.default_rng(seed)
        self.D, self.Q, self.F = D, Q, n_features
        self.ids = random_bipolar(rng, (n_features, D))
        self.levels = make_level_hvs(rng, Q, D)
        self.scaler = UnitScaler(scaling)

    def fit(self, X_train):
        self.scaler.fit(X_train)
        return self

    def quantize(self, X):
        return np.rint(self.scaler.transform(X) * (self.Q - 1)).astype(np.int64)

    def encode_sum(self, X, chunk: int = 512):
        q = self.quantize(X)
        out = np.empty((len(X), self.D), dtype=np.int16)
        for s in range(0, len(X), chunk):
            qs = q[s:s + chunk]
            acc = np.zeros((len(qs), self.D), dtype=np.int16)
            for f in range(self.F):
                acc += self.levels[qs[:, f]] * self.ids[f]
            out[s:s + chunk] = acc
        return out

    def encode(self, X, chunk: int = 512):
        return sign_tiebreak(self.encode_sum(X, chunk))


class AssociativeMemory:
    """Class prototypes. acc[k] = sum of encoded training HVs of class k (integer accumulator);
    the deployed binary prototype is sign(acc). Retrieval = argmax cosine similarity."""

    def __init__(self, n_classes: int, D: int):
        self.K, self.D = n_classes, D
        self.acc = np.zeros((n_classes, D), dtype=np.int32)

    def fit(self, H, y_idx):
        for k in range(self.K):
            self.acc[k] = H[y_idx == k].sum(axis=0, dtype=np.int32)
        return self

    @property
    def prototypes(self):
        return sign_tiebreak(self.acc)

    def scores(self, H, mode: str = "binary"):
        """Cosine similarity of bipolar queries to the stored prototypes."""
        if mode == "binary":      # both vectors bipolar: cos = dot / D (float32 exact for D < 2^24)
            return (H.astype(np.float32, copy=False) @ self.prototypes.astype(np.float32).T) / self.D
        A = self.acc.astype(np.float64)
        return (H.astype(np.float64) @ A.T) / (np.sqrt(self.D) * np.linalg.norm(A, axis=1))

    def predict(self, H, mode: str = "binary"):
        return self.scores(H, mode).argmax(axis=1)

    def retrain_epoch(self, H, y_idx):
        """One batch perceptron-style epoch: for each misclassified training HV, add it to the true class
        accumulator and subtract it from the predicted one (learning rate 1)."""
        pred = self.predict(H)
        mis = pred != y_idx
        if not mis.any():
            return 0
        Y = np.eye(self.K, dtype=np.float32)[y_idx[mis]]
        P = np.eye(self.K, dtype=np.float32)[pred[mis]]
        self.acc += np.rint((Y - P).T @ H[mis].astype(np.float32)).astype(np.int32)
        return int(mis.sum())
