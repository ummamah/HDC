"""Data loading, duplicate grouping and leakage-free splitting.

Split strategy (applies to BOTH protocols):
  1. Identical feature vectors are grouped ("records"). No label conflicts exist in this dataset (asserted).
  2. The *unique records* are split 60/20/20 with stratification on the original quality label.
  3. dedup protocol   : each split contains each unique record once.
     nodedup protocol : each record's original duplicates travel with it into the same split.
  => an exact record can never appear in two different splits, in either protocol.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split

TARGET = "quality"


def load_wine(path):
    df = pd.read_csv(path, sep=";")
    feats = [c for c in df.columns if c != TARGET]
    return df[feats].to_numpy(dtype=np.float64), df[TARGET].to_numpy(dtype=np.int64), feats


@dataclass
class Groups:
    first_idx: np.ndarray   # (U,) row index of the first occurrence of each unique record
    inverse: np.ndarray     # (N,) group id of every row


def group_duplicates(X, y) -> Groups:
    _, first_idx, inverse = np.unique(X, axis=0, return_index=True, return_inverse=True)
    inverse = inverse.reshape(-1)
    assert (y[first_idx][inverse] == y).all(), "duplicate feature rows with conflicting labels"
    return Groups(first_idx=first_idx, inverse=inverse)


@dataclass
class Split:
    train: np.ndarray  # row indices into the original arrays
    val: np.ndarray
    test: np.ndarray


def make_split(y, groups: Groups, seed: int, protocol: str, fractions=(0.6, 0.2, 0.2)) -> Split:
    f_tr, f_va, f_te = fractions
    assert abs(f_tr + f_va + f_te - 1) < 1e-9 and protocol in ("dedup", "nodedup")
    yu = y[groups.first_idx]
    g = np.arange(len(yu))
    g_tv, g_te = train_test_split(g, test_size=f_te, stratify=yu, random_state=seed)
    g_tr, g_va = train_test_split(g_tv, test_size=f_va / (f_tr + f_va), stratify=yu[g_tv], random_state=seed)

    def rows(gs):
        if protocol == "dedup":
            return np.sort(groups.first_idx[gs])
        return np.flatnonzero(np.isin(groups.inverse, gs))
    return Split(rows(g_tr), rows(g_va), rows(g_te))


def audit_split(X, y, groups: Groups, split: Split, protocol: str, labels) -> dict:
    """Programmatic leakage / sanity checks. Raises AssertionError on any violation."""
    parts = {"train": split.train, "val": split.val, "test": split.test}
    hashes = {k: {X[i].tobytes() for i in v} for k, v in parts.items()}
    for a, b in (("train", "val"), ("train", "test"), ("val", "test")):
        assert hashes[a].isdisjoint(hashes[b]), f"exact-record leakage between {a} and {b}"
        assert set(parts[a]).isdisjoint(parts[b])
    all_rows = np.concatenate(list(parts.values()))
    assert len(all_rows) == len(set(all_rows.tolist()))
    expected = len(groups.first_idx) if protocol == "dedup" else len(y)
    assert len(all_rows) == expected, "split does not cover the protocol's data exactly"
    if protocol == "dedup":
        for k, v in parts.items():
            assert len(hashes[k]) == len(v), f"duplicate rows inside {k} under dedup"
    out = {"protocol": protocol}
    for k, v in parts.items():
        cnt = {int(l): int((y[v] == l).sum()) for l in labels}
        assert all(c >= 1 for c in cnt.values()), f"a class is missing from {k}: {cnt}"
        out[k] = {"n": int(len(v)), "n_unique_records": len(hashes[k]), "class_counts": cnt}
    return out


def to_task(y, task):
    if task == "original":
        return y
    if task == "grouped3":   # <=5 -> 0, 6 -> 1, >=7 -> 2   (secondary task, NOT the original labels)
        return np.where(y <= 5, 0, np.where(y == 6, 1, 2)).astype(np.int64)
    raise ValueError(task)
