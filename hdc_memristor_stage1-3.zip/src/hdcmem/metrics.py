import numpy as np
from sklearn.metrics import accuracy_score, balanced_accuracy_score, confusion_matrix, f1_score


def macro_f1(y_true, y_pred, labels):
    return float(f1_score(y_true, y_pred, labels=labels, average="macro", zero_division=0))


def evaluate(y_true, y_pred, labels) -> dict:
    """All classes are present in every evaluated set (enforced by audit_split), so balanced accuracy is well defined."""
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_f1": macro_f1(y_true, y_pred, labels),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "mean_abs_label_error": float(np.abs(np.asarray(y_true) - np.asarray(y_pred)).mean()),  # label units
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels=labels).tolist(),  # rows=true, cols=pred
    }
