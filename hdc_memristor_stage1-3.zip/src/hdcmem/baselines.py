"""Conventional software baselines. Every model is fit on the training rows only; hyper-parameters are chosen on
the validation rows only (macro-F1). Scalers live inside the pipeline, so they too are fit on training rows only."""
from __future__ import annotations
import numpy as np
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier, NearestCentroid
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from .metrics import evaluate, macro_f1


def grids(cfg):
    g = {"majority": [{}],
         "centroid": [{}],
         "knn": [{"k": k} for k in cfg["knn_k"]],
         "logreg": [{"C": C, "class_weight": cw} for C in cfg["logreg_C"] for cw in cfg["class_weight"]],
         "rf": [{"min_samples_leaf": m, "class_weight": cw if cw is None else "balanced_subsample"}
                for m in cfg["rf_min_samples_leaf"] for cw in cfg["class_weight"]]}
    return g


def build(name, p, seed, rf_trees):
    if name == "majority":
        return DummyClassifier(strategy="most_frequent")
    if name == "centroid":
        return make_pipeline(StandardScaler(), NearestCentroid())
    if name == "knn":
        return make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=p["k"]))
    if name == "logreg":
        return make_pipeline(StandardScaler(), LogisticRegression(C=p["C"], class_weight=p["class_weight"], max_iter=5000))
    if name == "rf":
        return RandomForestClassifier(n_estimators=rf_trees, min_samples_leaf=p["min_samples_leaf"],
                                      class_weight=p["class_weight"], random_state=seed, n_jobs=1)
    raise ValueError(name)


def select_and_evaluate(name, grid, Xtr, ytr, Xva, yva, Xte, yte, labels, seed, rf_trees):
    best = None
    for p in grid:
        m = build(name, p, seed, rf_trees).fit(Xtr, ytr)
        v = macro_f1(yva, m.predict(Xva), labels)
        if best is None or v > best[0]:                       # strict '>' keeps the first of any tie
            best = (v, p, m)
    v, p, m = best
    return {"model": name, "params": p, "val_macro_f1": v, **evaluate(yte, m.predict(Xte), labels)}
