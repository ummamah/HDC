"""
Hierarchical / Clustered Statistical Audit of Margin-AUROC.
Audits the dependence structure of margin_records.jsonl:
  - 10 distinct stratified splits (Trials 0 to 9)
  - 793 unique held-out test queries per split
  - Computes:
      1. Trial-stratified AUROC (per-split AUROC, then Mean ± Std, 95% Student-t CI over splits)
      2. Cluster-bootstrapped AUROC (resampling entire splits with replacement, 2,000 iterations)
      3. Flat pooled AUROC with percentile bootstrap (for comparison)
Outputs results to results/stage5/hierarchical_margin_auroc_audit.csv
"""
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results" / "stage5"
margin_path = OUT / "margin_records.jsonl"

print("Loading margin records...")
rows = [json.loads(line) for line in open(margin_path)]
df = pd.DataFrame(rows)

print(f"Total margin records loaded: {len(df)}")
print(f"Trials: {sorted(df['trial'].unique().tolist())}")
print(f"Queries per trial: {df.groupby('trial')['query_idx'].nunique().to_dict()}")

# Group by non-ideality condition
conditions = df.groupby(["non_ideality_type", "param_value"])

audit_records = []
rng = np.random.default_rng(2026)

for (n_type, p_val), g in conditions:
    # 1. Total counts
    n_samples = len(g)
    n_flips = int(g["retrieval_error"].sum())
    flip_rate = n_flips / n_samples
    
    # 2. Flat Pooled AUROC
    y_true_all = g["retrieval_error"].values
    scores_all = -g["ideal_margin"].values
    if 0 < n_flips < n_samples:
        flat_auroc = float(roc_auc_score(y_true_all, scores_all))
    else:
        flat_auroc = np.nan

    # 3. Per-Trial AUROCs (Split-level estimation)
    trial_aucs = []
    trial_flip_counts = []
    trial_n_samples = []
    
    trials = sorted(g["trial"].unique())
    for tr in trials:
        tg = g[g["trial"] == tr]
        yt_tr = tg["retrieval_error"].values
        sc_tr = -tg["ideal_margin"].values
        n_tr_flips = int(yt_tr.sum())
        trial_flip_counts.append(n_tr_flips)
        trial_n_samples.append(len(yt_tr))
        if 0 < n_tr_flips < len(yt_tr):
            trial_aucs.append(roc_auc_score(yt_tr, sc_tr))
    
    n_eval_trials = len(trial_aucs)
    if n_eval_trials > 1:
        trial_mean = float(np.mean(trial_aucs))
        trial_std = float(np.std(trial_aucs, ddof=1))
        # 95% Student-t CI across splits
        t_crit = stats.t.ppf(0.975, df=n_eval_trials - 1)
        trial_ci_lo = trial_mean - t_crit * trial_std / np.sqrt(n_eval_trials)
        trial_ci_hi = trial_mean + t_crit * trial_std / np.sqrt(n_eval_trials)
    elif n_eval_trials == 1:
        trial_mean = float(trial_aucs[0])
        trial_std = 0.0
        trial_ci_lo, trial_ci_hi = trial_mean, trial_mean
    else:
        trial_mean, trial_std, trial_ci_lo, trial_ci_hi = np.nan, np.nan, np.nan, np.nan

    # 4. Cluster Bootstrap over Splits (Resampling 10 clusters with replacement, 2,000 iterations)
    n_boot = 2000
    cluster_aucs = []
    if 0 < n_flips < n_samples:
        trial_groups = [g[g["trial"] == tr] for tr in trials]
        for _ in range(n_boot):
            sampled_tr_idx = rng.choice(len(trial_groups), size=len(trial_groups), replace=True)
            sampled_df = pd.concat([trial_groups[idx] for idx in sampled_tr_idx], ignore_index=True)
            yt_b = sampled_df["retrieval_error"].values
            sc_b = -sampled_df["ideal_margin"].values
            if 0 < yt_b.sum() < len(yt_b):
                cluster_aucs.append(roc_auc_score(yt_b, sc_b))
        
        if len(cluster_aucs) > 0:
            cl_ci_lo, cl_ci_hi = np.percentile(cluster_aucs, [2.5, 97.5])
            cl_mean = float(np.mean(cluster_aucs))
        else:
            cl_mean, cl_ci_lo, cl_ci_hi = np.nan, np.nan, np.nan
    else:
        cl_mean, cl_ci_lo, cl_ci_hi = np.nan, np.nan, np.nan

    rec = {
        "non_ideality_type": n_type,
        "param_value": p_val,
        "total_queries": n_samples,
        "n_splits": len(trials),
        "total_retrieval_flips": n_flips,
        "flip_rate": flip_rate,
        "flat_pooled_auroc": flat_auroc,
        "valid_splits_with_flips": n_eval_trials,
        "trial_mean_auroc": trial_mean,
        "trial_std_auroc": trial_std,
        "trial_student_t_ci_lo": trial_ci_lo,
        "trial_student_t_ci_hi": trial_ci_hi,
        "cluster_bootstrap_mean_auroc": cl_mean,
        "cluster_bootstrap_ci_lo": cl_ci_lo,
        "cluster_bootstrap_ci_hi": cl_ci_hi,
    }
    audit_records.append(rec)
    print(f"Condition {n_type:22s} {str(p_val):6s} | Flips: {n_flips:4d}/{n_samples} | Trial Mean AUROC: {trial_mean:.4f} [t-CI: {trial_ci_lo:.4f}, {trial_ci_hi:.4f}] | Cluster-Boot CI: [{cl_ci_lo:.4f}, {cl_ci_hi:.4f}]")

res_df = pd.DataFrame(audit_records)
res_df.to_csv(OUT / "hierarchical_margin_auroc_audit.csv", index=False)
print(f"Saved hierarchical audit to {OUT / 'hierarchical_margin_auroc_audit.csv'}")
