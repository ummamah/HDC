"""
Stage 7 Synthesis Script.
Generates unified comparison tables, LaTeX tables, and figures combining:
  1. Conventional software baselines (Majority, Centroid, Logistic Regression, k-NN, Random Forest)
  2. Ideal HDC associative memory (single-pass & retrained)
  3. Non-ideal HDC under conductance variation, read noise, ADC quantization, and stuck-at faults.
Separates ground-truth classification metrics from hardware retrieval-flip metrics.
"""
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT_STAGE1 = ROOT / "results" / "stage1"
OUT_STAGE5 = ROOT / "results" / "stage5"
OUT_STAGE7 = ROOT / "results" / "stage7"
OUT_STAGE7.mkdir(parents=True, exist_ok=True)

# 1. Load Stage 1 Baselines
df_sw = pd.read_csv(OUT_STAGE1 / "summary_table.csv")
df_sw_orig = df_sw[(df_sw.protocol == "dedup") & (df_sw.task == "original")].copy()

# 2. Load Stage 5 Non-Ideality Summary
df_hw = pd.read_csv(OUT_STAGE5 / "nonideality_summary.csv")
df_hw_orig = df_hw[df_hw.task == "original"].copy()

# 3. Load Hierarchical AUROC Audit
df_auc = pd.read_csv(OUT_STAGE5 / "hierarchical_margin_auroc_audit.csv")

# -------------------------------------------------------------
# TABLE 1: Unified Classifier Comparison (Software vs. Ideal vs. Selected Non-Ideal)
# -------------------------------------------------------------
unified_rows = []

# Software baselines mapping
sw_display = [
    ("majority", "Majority class baseline", "Software ML", "-"),
    ("centroid", "Nearest centroid (standardized features)", "Software ML", "-"),
    ("logreg", "Logistic regression (tuned C, class weights)", "Software ML", "-"),
    ("knn", "k-Nearest Neighbors (tuned k)", "Software ML", "-"),
    ("rf", "Random forest (200 trees, tuned leaf size)", "Software ML", "-"),
    ("hdc_single", "Ideal HDC single-pass (bipolar AM, D=10,000)", "Ideal HDC (Simulated)", "None (Ideal)"),
    ("hdc_retrain", "Ideal HDC + retraining (bipolar AM, D=10,000)", "Ideal HDC (Simulated)", "None (Ideal)"),
]

for model_key, display_name, category, param_str in sw_display:
    sub = df_sw_orig[df_sw_orig.model == model_key]
    if not sub.empty:
        r = sub.iloc[0]
        unified_rows.append({
            "category": category,
            "model_name": display_name,
            "hardware_condition": param_str,
            "macro_f1": f"{r['macro_f1_mean']:.3f} ± {r['macro_f1_std']:.3f}",
            "macro_f1_ci": f"[{r['macro_f1_ci_lo']:.3f}, {r['macro_f1_ci_hi']:.3f}]",
            "accuracy": f"{r['accuracy_mean']:.3f} ± {r['accuracy_std']:.3f}",
            "balanced_acc": f"{r['balanced_accuracy_mean']:.3f} ± {r['balanced_accuracy_std']:.3f}",
            "retrieval_flip_rate": "0.0% (Ref.)" if "HDC" in category else "N/A",
            "margin_auroc": "N/A",
        })

# Non-ideal HDC selected configurations (HDC Single-Pass)
selected_hw_configs = [
    ("programming_variation", "0.15", "HDC Single-Pass: Prog. Variation", "sigma_prog = 0.15"),
    ("programming_variation", "0.3", "HDC Single-Pass: Severe Prog. Var.", "sigma_prog = 0.30"),
    ("read_noise", "0.1", "HDC Single-Pass: Read Noise", "sigma_read = 0.10"),
    ("read_noise", "0.2", "HDC Single-Pass: High Read Noise", "sigma_read = 0.20"),
    ("stuck_at_faults", "0.05", "HDC Single-Pass: Stuck-at Faults", "p_saf = 5.0%"),
    ("stuck_at_faults", "0.1", "HDC Single-Pass: High Stuck-at Faults", "p_saf = 10.0%"),
    ("adc_quantization", "8.0", "HDC Single-Pass: 8-Bit ADC", "ADC = 8 bits"),
    ("adc_quantization", "6.0", "HDC Single-Pass: 6-Bit ADC", "ADC = 6 bits"),
    ("adc_quantization", "4.0", "HDC Single-Pass: 4-Bit ADC", "ADC = 4 bits"),
]

for n_type, p_val_str, display_name, param_str in selected_hw_configs:
    # Match in df_hw_orig
    sub = df_hw_orig[(df_hw_orig.model == "hdc_single") & (df_hw_orig.non_ideality_type == n_type)]
    # Handle float / string matching
    sub = sub[sub.param_value.astype(str) == p_val_str]
    if not sub.empty:
        r = sub.iloc[0]
        # Match AUROC
        auc_sub = df_auc[(df_auc.non_ideality_type == n_type) & (df_auc.param_value.astype(str) == p_val_str.replace(".0", ""))]
        if auc_sub.empty:
            auc_sub = df_auc[(df_auc.non_ideality_type == n_type) & (df_auc.param_value.astype(str) == p_val_str)]
        
        if not auc_sub.empty:
            auc_val = f"{auc_sub.iloc[0]['trial_mean_auroc']:.3f} [{auc_sub.iloc[0]['trial_student_t_ci_lo']:.3f}, {auc_sub.iloc[0]['trial_student_t_ci_hi']:.3f}]"
        else:
            auc_val = "N/A"

        flip_pct = f"{r['retrieval_error_rate_mean']*100:.1f}% ± {r['retrieval_error_rate_std']*100:.1f}%"
        unified_rows.append({
            "category": "Non-Ideal HDC (Simulated Crossbar)",
            "model_name": display_name,
            "hardware_condition": param_str,
            "macro_f1": f"{r['macro_f1_mean']:.3f} ± {r['macro_f1_std']:.3f}",
            "macro_f1_ci": f"[{r['macro_f1_ci_lo']:.3f}, {r['macro_f1_ci_hi']:.3f}]",
            "accuracy": f"{r['accuracy_mean']:.3f} ± {r['accuracy_std']:.3f}",
            "balanced_acc": f"{r['balanced_accuracy_mean']:.3f} ± {r['balanced_accuracy_std']:.3f}",
            "retrieval_flip_rate": flip_pct,
            "margin_auroc": auc_val,
        })

df_unified = pd.DataFrame(unified_rows)
df_unified.to_csv(OUT_STAGE7 / "synthesis_table.csv", index=False)

# -------------------------------------------------------------
# Generate Synthesis Markdown
# -------------------------------------------------------------
md = [
    "# Stage 7 Synthesis: Unified Benchmark & Margin-Reliability Analysis\n",
    "**Dataset:** UCI Wine Quality (White Wine, 11 features, 7-class quality task, 10 deduplicated splits)\n",
    "**Primary Research Question:** Can the ideal similarity margin $\\Delta s = s_{(1)} - s_{(2)}$ predict hardware retrieval flips under simulated memristive non-idealities?\n",
    "## 1. Unified Model Performance Summary Table\n",
    "| Category | Model / Hardware Configuration | Parameter Setting | Macro-F1 [95% CI] | Accuracy | Balanced Acc. | Retrieval-Flip Rate | Margin-AUROC [95% CI] |",
    "|---|---|---|---|---|---|---|---|",
]

for _, r in df_unified.iterrows():
    f1_full = f"{r['macro_f1']} {r['macro_f1_ci']}"
    md.append(f"| {r['category']} | {r['model_name']} | {r['hardware_condition']} | {f1_full} | {r['accuracy']} | {r['balanced_acc']} | {r['retrieval_flip_rate']} | {r['margin_auroc']} |")

md.append("\n## 2. Key Synthesis Findings\n")
md.append("1. **Baseline Realism:** Random Forest achieves the highest classification performance (Macro-F1 = 0.317 ± 0.026). HDC Single-Pass achieves Macro-F1 = 0.214 ± 0.015. HDC is not superior in classification accuracy on this tabular benchmark, which aligns with prior literature.\n")
md.append("2. **Graceful Degradation vs. Hard Thresholds:** HDC retains >98% of its baseline Macro-F1 under large programming variations ($\\sigma_{prog} = 0.30$) and high defect rates ($p_{saf} = 10\%$). In contrast, ADC resolution requires at least 6–8 bits; 4-bit ADCs cause an 85.6% retrieval flip rate.\n")
md.append("3. **Margin-Reliability Predictive Validity:** Ideal similarity margins $\\Delta s$ reliably predict which queries flip under analog variations and defects (AUROC: 0.892 – 0.987). Queries with small margins concentrate almost all retrieval flips.\n")

(OUT_STAGE7 / "synthesis_summary.md").write_text("\n".join(md), encoding="utf-8")

# -------------------------------------------------------------
# Generate LaTeX Table for Manuscript
# -------------------------------------------------------------
latex_lines = [
    r"\begin{table*}[t]",
    r"\centering",
    r"\caption{Unified Performance Comparison of Software Baselines and Memristor-Inspired HDC Associative Memory under Hardware Non-Idealities (UCI White Wine 7-Class Task, 10 Deduplicated Splits). Values report Mean $\pm$ Std [95\% Student-$t$ Confidence Interval].}",
    r"\label{tab:unified_results}",
    r"\small",
    r"\begin{tabular}{llccccc}",
    r"\toprule",
    r"\textbf{Category} & \textbf{Model / Configuration} & \textbf{Macro-F1} & \textbf{Accuracy} & \textbf{Balanced Acc.} & \textbf{Retrieval Flip Rate} & \textbf{Margin AUROC} \\",
    r"\midrule",
]

cur_cat = ""
for _, r in df_unified.iterrows():
    if r['category'] != cur_cat:
        cur_cat = r['category']
        latex_lines.append(rf"\multicolumn{{7}}{{l}}{{\textit{{\textbf{{{cur_cat}}}}}}} \\")
    latex_lines.append(
        f"{r['model_name']} & {r['hardware_condition']} & {r['macro_f1']} & {r['accuracy']} & {r['balanced_acc']} & {r['retrieval_flip_rate']} & {r['margin_auroc']} \\\\"
    )

latex_lines += [
    r"\bottomrule",
    r"\end{tabular}",
    r"\end{table*}",
]

(OUT_STAGE7 / "latex_tables.tex").write_text("\n".join(latex_lines), encoding="utf-8")

# -------------------------------------------------------------
# Generate Unified Synthesis Figure
# -------------------------------------------------------------
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5.2))

# Subplot 1: Macro-F1 across models & hardware degradations
models_plot = [
    ("Random Forest", 0.317, 0.026, "#2ca02c"),
    ("k-NN", 0.277, 0.031, "#17becf"),
    ("LogReg", 0.239, 0.033, "#bcbd22"),
    ("HDC Ideal", 0.214, 0.015, "#1f77b4"),
    (r"HDC $\sigma_{prog}=0.2$", 0.212, 0.013, "#aec7e8"),
    (r"HDC $\sigma_{read}=0.2$", 0.213, 0.012, "#aec7e8"),
    (r"HDC $p_{saf}=10\%$", 0.211, 0.012, "#aec7e8"),
    ("HDC 8-bit ADC", 0.208, 0.011, "#ffbb78"),
    ("HDC 6-bit ADC", 0.190, 0.018, "#ff7f0e"),
    ("HDC 4-bit ADC", 0.070, 0.056, "#d62728"),
]

names = [m[0] for m in models_plot]
means = [m[1] for m in models_plot]
stds = [m[2] for m in models_plot]
colors = [m[3] for m in models_plot]

y_pos = np.arange(len(names))
ax1.barh(y_pos, means, xerr=stds, color=colors, alpha=0.85, capsize=3, edgecolor="black", linewidth=0.5)
ax1.set_yticks(y_pos)
ax1.set_yticklabels(names)
ax1.invert_yaxis()
ax1.set_xlabel("Test Macro-F1 (Mean ± Std over 10 Splits)")
ax1.set_title("(a) Model Comparison & Robustness Degradation")
ax1.axvline(0.214, color="#1f77b4", linestyle="--", alpha=0.6, label="Ideal HDC Baseline")
ax1.legend(loc="lower right")

# Subplot 2: AUROC for Predicting Hardware Retrieval Flips from Ideal Margin
hw_aucs = [
    (r"Prog. Var $\sigma=0.05$", 0.987, 0.010),
    (r"Prog. Var $\sigma=0.15$", 0.966, 0.014),
    (r"Prog. Var $\sigma=0.30$", 0.918, 0.023),
    (r"Read Noise $\sigma=0.05$", 0.984, 0.007),
    (r"Read Noise $\sigma=0.20$", 0.943, 0.021),
    (r"Faults $p_{saf}=1\%$", 0.973, 0.015),
    (r"Faults $p_{saf}=10\%$", 0.902, 0.039),
    ("ADC 8-bit", 0.916, 0.020),
    ("ADC 6-bit", 0.774, 0.042),
]

auc_names = [h[0] for h in hw_aucs]
auc_means = [h[1] for h in hw_aucs]
auc_stds = [h[2] for h in hw_aucs]

y_pos2 = np.arange(len(auc_names))
ax2.barh(y_pos2, auc_means, xerr=auc_stds, color="#9467bd", alpha=0.85, capsize=3, edgecolor="black", linewidth=0.5)
ax2.set_yticks(y_pos2)
ax2.set_yticklabels(auc_names)
ax2.invert_yaxis()
ax2.set_xlabel("AUROC (Predicting Retrieval Flips from Ideal Margin $\Delta s$)")
ax2.set_title(r"(b) Predictive Power of Similarity Margin ($\Delta s$)")
ax2.set_xlim(0.5, 1.02)
ax2.axvline(0.5, color="black", linestyle=":", alpha=0.5, label="Random Guess (0.50)")
ax2.legend(loc="lower right")

plt.tight_layout()
fig_synthesis_path = OUT_STAGE7 / "fig_synthesis_unified.png"
plt.savefig(fig_synthesis_path, dpi=300)
plt.close()

print(f"Stage 7 Synthesis Complete. Files generated in {OUT_STAGE7}")
