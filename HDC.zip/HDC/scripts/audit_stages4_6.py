"""
Scientific Audit Script for Stages 4, 5, and 6.
Audits the raw JSONL records, recalculates all metrics, checks noise implementations,
audits AUROC calculations with bootstrapping for confidence intervals,
and checks for mathematical and implementation anomalies.
"""
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results" / "stage5"

raw_res_path = OUT / "raw_nonideality_results.jsonl"
margin_path = OUT / "margin_records.jsonl"

print("--- 1. LOADING AND AUDITING RAW NON-IDEALITY RESULTS ---")
res_rows = [json.loads(line) for line in open(raw_res_path)]
df_res = pd.DataFrame(res_rows)
print(f"Total raw result records: {len(df_res)}")
print(f"Unique models: {df_res['model'].unique()}")
print(f"Unique non-ideality types: {df_res['non_ideality_type'].unique()}")
print(f"Unique tasks: {df_res['task'].unique()}")
print(f"Unique trials: {df_res['trial'].unique()}")
print(f"Unique MC trials: {df_res['mc_trial'].unique()}")

# Check ideal baseline values across trials
df_ideal = df_res[df_res["non_ideality_type"] == "ideal"]
print("\nIdeal baseline records across 10 trials:")
for (task, model), g in df_ideal.groupby(["task", "model"]):
    print(f"Task: {task}, Model: {model}")
    print(f"  Accuracy: {g['accuracy'].mean():.4f} +/- {g['accuracy'].std():.4f}")
    print(f"  Macro-F1: {g['macro_f1'].mean():.4f} +/- {g['macro_f1'].std():.4f}")
    print(f"  Balanced Acc: {g['balanced_accuracy'].mean():.4f} +/- {g['balanced_accuracy'].std():.4f}")

# Check retrieval flip rates
print("\n--- 2. AUDITING RETRIEVAL FLIP RATES VS CLASSIFICATION ACCURACY ---")
for model in ["hdc_single", "hdc_retrain"]:
    print(f"\nModel: {model} (Task: original)")
    sub = df_res[(df_res["task"] == "original") & (df_res["model"] == model)]
    for n_type in ["programming_variation", "read_noise", "stuck_at_faults", "adc_quantization"]:
        g = sub[sub["non_ideality_type"] == n_type]
        for p_val, pg in g.groupby("param_value"):
            flip_mean = pg["retrieval_error_rate"].mean()
            flip_std = pg["retrieval_error_rate"].std()
            acc_mean = pg["accuracy"].mean()
            f1_mean = pg["macro_f1"].mean()
            print(f"  {n_type:22s} | param: {str(p_val):6s} | Flip Rate: {flip_mean:.4f} +/- {flip_std:.4f} | Acc: {acc_mean:.4f} | Macro-F1: {f1_mean:.4f}")

print("\n--- 3. AUDITING MARGIN RECORDS & AUROC WITH BOOTSTRAP CI ---")
m_rows = [json.loads(line) for line in open(margin_path)]
df_m = pd.DataFrame(m_rows)
print(f"Total margin records: {len(df_m)}")
print(f"Columns in margin records: {df_m.columns.tolist()}")

# Check if ideal_margin is strictly non-negative
neg_margins = (df_m["ideal_margin"] < 0).sum()
print(f"Negative ideal margins count: {neg_margins} (Must be 0)")
print(f"Ideal margin summary: min={df_m['ideal_margin'].min():.6f}, max={df_m['ideal_margin'].max():.6f}, mean={df_m['ideal_margin'].mean():.6f}")

# Bootstrap AUROC CI function
def bootstrap_auc(y_true, scores, n_boot=1000, seed=42):
    rng = np.random.default_rng(seed)
    n = len(y_true)
    if y_true.sum() == 0 or y_true.sum() == n:
        return np.nan, (np.nan, np.nan)
    base_auc = roc_auc_score(y_true, scores)
    boot_aucs = []
    for _ in range(n_boot):
        idx = rng.choice(n, size=n, replace=True)
        yt_b = y_true[idx]
        sc_b = scores[idx]
        if yt_b.sum() > 0 and yt_b.sum() < n:
            boot_aucs.append(roc_auc_score(yt_b, sc_b))
    if len(boot_aucs) > 0:
        ci_lo, ci_hi = np.percentile(boot_aucs, [2.5, 97.5])
    else:
        ci_lo, ci_hi = np.nan, np.nan
    return base_auc, (ci_lo, ci_hi)

# Evaluate AUROC per trial and pooled
print("\nMargin AUROC Breakdown (Predicting Retrieval Flips from -IdealMargin):")
auroc_audit_results = []
for (n_type, p_val), g in df_m.groupby(["non_ideality_type", "param_value"]):
    y_true = g["retrieval_error"].values
    scores = -g["ideal_margin"].values
    n_flips = int(y_true.sum())
    n_tot = len(y_true)
    auc_pooled, (ci_lo, ci_hi) = bootstrap_auc(y_true, scores, n_boot=500)
    
    # Also calculate per-trial AUROCs to verify trial consistency
    trial_aucs = []
    for tr, tg in g.groupby("trial"):
        yt_tr = tg["retrieval_error"].values
        sc_tr = -tg["ideal_margin"].values
        if yt_tr.sum() > 0 and yt_tr.sum() < len(yt_tr):
            trial_aucs.append(roc_auc_score(yt_tr, sc_tr))
    
    tr_mean = np.mean(trial_aucs) if len(trial_aucs) > 0 else np.nan
    tr_std = np.std(trial_aucs) if len(trial_aucs) > 0 else np.nan
    
    print(f"  {n_type:22s} | param: {str(p_val):6s} | Flips: {n_flips:4d}/{n_tot} ({n_flips/n_tot:6.3f}) | Pooled AUROC: {auc_pooled:.4f} [95% CI: {ci_lo:.4f}, {ci_hi:.4f}] | Mean Trial AUROC: {tr_mean:.4f} +/- {tr_std:.4f} (n_trials={len(trial_aucs)})")
    
    auroc_audit_results.append({
        "non_ideality_type": n_type,
        "param_value": p_val,
        "n_samples": n_tot,
        "n_flips": n_flips,
        "flip_rate": n_flips / n_tot,
        "pooled_auroc": auc_pooled,
        "ci_lo": ci_lo,
        "ci_hi": ci_hi,
        "trial_mean_auroc": tr_mean,
        "trial_std_auroc": tr_std,
    })

pd.DataFrame(auroc_audit_results).to_csv(OUT / "audit_auroc_recalculated.csv", index=False)
print(f"\nAudit complete. Recalculated AUROCs saved to {OUT / 'audit_auroc_recalculated.csv'}")
