"""
Generate publication-quality figures for Stage 5 & 6 non-ideality and margin analysis.
Outputs:
  - results/stage5/fig_nonideality_sweeps.png (Robustness curves across 4 non-idealities)
  - results/stage5/fig_margin_error_relationship.png (Error probability vs margin & ROC curves)

Usage:
  python scripts/05_plot_nonidealities.py [results_dir]
"""
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, roc_auc_score

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "results" / "stage5"


def main():
    summary_path = OUT / "nonideality_summary.csv"
    margin_path = OUT / "margin_records.jsonl"

    if not summary_path.exists():
        print(f"Error: {summary_path} not found.")
        sys.exit(1)

    df_sum = pd.read_csv(summary_path)

    # Plot styling
    plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")
    plt.rcParams.update({
        "font.size": 11,
        "axes.labelsize": 12,
        "axes.titlesize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
        "legend.fontsize": 10,
        "figure.titlesize": 14,
    })

    # -------------------------------------------------------------
    # FIGURE 1: 4-Panel Non-Ideality Robustness Curves
    # -------------------------------------------------------------
    fig, axes = plt.subplots(2, 2, figsize=(12, 9))

    # Panel A: Programming Variation (sigma_prog)
    ax = axes[0, 0]
    for model, label, color, marker in [
        ("hdc_single", "HDC Single-Pass", "#1f77b4", "o"),
        ("hdc_retrain", "HDC + Retraining", "#ff7f0e", "s"),
    ]:
        sub = df_sum[(df_sum.task == "original") & (df_sum.model == model) & (df_sum.non_ideality_type == "programming_variation")]
        if not sub.empty:
            sub = sub.sort_values("param_value")
            x = sub["param_value"].astype(float).values
            y = sub["macro_f1_mean"].values
            err_lo = y - sub["macro_f1_ci_lo"].values
            err_hi = sub["macro_f1_ci_hi"].values - y
            ax.errorbar(x, y, yerr=[err_lo, err_hi], label=label, color=color, marker=marker, capsize=3, lw=2)
    ax.set_title("(a) Programming Variation ($\sigma_{prog}$)")
    ax.set_xlabel("Variation std $\sigma_{prog}$ (normalized conductance)")
    ax.set_ylabel("Test Macro-F1 (7-Class)")
    ax.legend(frameon=True)
    ax.set_ylim(0.0, 0.35)

    # Panel B: Read Noise (sigma_read)
    ax = axes[0, 1]
    for model, label, color, marker in [
        ("hdc_single", "HDC Single-Pass", "#1f77b4", "o"),
        ("hdc_retrain", "HDC + Retraining", "#ff7f0e", "s"),
    ]:
        sub = df_sum[(df_sum.task == "original") & (df_sum.model == model) & (df_sum.non_ideality_type == "read_noise")]
        if not sub.empty:
            sub = sub.sort_values("param_value")
            x = sub["param_value"].astype(float).values
            y = sub["macro_f1_mean"].values
            err_lo = y - sub["macro_f1_ci_lo"].values
            err_hi = sub["macro_f1_ci_hi"].values - y
            ax.errorbar(x, y, yerr=[err_lo, err_hi], label=label, color=color, marker=marker, capsize=3, lw=2)
    ax.set_title("(b) Read Noise ($\sigma_{read}$)")
    ax.set_xlabel("Read noise std $\sigma_{read}$")
    ax.set_ylabel("Test Macro-F1 (7-Class)")
    ax.legend(frameon=True)
    ax.set_ylim(0.0, 0.35)

    # Panel C: ADC Bit Resolution
    ax = axes[1, 0]
    for model, label, color, marker in [
        ("hdc_single", "HDC Single-Pass", "#1f77b4", "o"),
        ("hdc_retrain", "HDC + Retraining", "#ff7f0e", "s"),
    ]:
        sub = df_sum[(df_sum.task == "original") & (df_sum.model == model) & (df_sum.non_ideality_type == "adc_quantization")]
        if not sub.empty:
            sub = sub[sub.param_value != "none"].sort_values("param_value")
            x = sub["param_value"].astype(int).values
            y = sub["macro_f1_mean"].values
            err_lo = y - sub["macro_f1_ci_lo"].values
            err_hi = sub["macro_f1_ci_hi"].values - y
            ax.errorbar(x, y, yerr=[err_lo, err_hi], label=label, color=color, marker=marker, capsize=3, lw=2)
    ax.set_title("(c) Output ADC Resolution")
    ax.set_xlabel("ADC Resolution (Bits)")
    ax.set_ylabel("Test Macro-F1 (7-Class)")
    ax.legend(frameon=True)
    ax.set_ylim(0.0, 0.35)

    # Panel D: Stuck-at Faults (p_saf)
    ax = axes[1, 1]
    for model, label, color, marker in [
        ("hdc_single", "HDC Single-Pass", "#1f77b4", "o"),
        ("hdc_retrain", "HDC + Retraining", "#ff7f0e", "s"),
    ]:
        sub = df_sum[(df_sum.task == "original") & (df_sum.model == model) & (df_sum.non_ideality_type == "stuck_at_faults")]
        if not sub.empty:
            sub = sub.sort_values("param_value")
            x = sub["param_value"].astype(float).values * 100.0  # Percentage
            y = sub["macro_f1_mean"].values
            err_lo = y - sub["macro_f1_ci_lo"].values
            err_hi = sub["macro_f1_ci_hi"].values - y
            ax.errorbar(x, y, yerr=[err_lo, err_hi], label=label, color=color, marker=marker, capsize=3, lw=2)
    ax.set_title("(d) Stuck-At Faults ($p_{saf}$)")
    ax.set_xlabel("Defect Rate $p_{saf}$ (%)")
    ax.set_ylabel("Test Macro-F1 (7-Class)")
    ax.legend(frameon=True)
    ax.set_ylim(0.0, 0.35)

    plt.tight_layout()
    fig_path1 = OUT / "fig_nonideality_sweeps.png"
    plt.savefig(fig_path1, dpi=300)
    plt.close()
    print(f"Saved {fig_path1}")

    # -------------------------------------------------------------
    # FIGURE 2: Similarity Margin vs Retrieval Error Analysis
    # -------------------------------------------------------------
    if margin_path.exists():
        m_rows = [json.loads(line) for line in open(margin_path)]
        m_df = pd.DataFrame(m_rows)

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5.5))

        # Subplot 1: Error Probability vs Ideal Margin Bins
        # Select representative non-idealities: e.g. sigma_prog = 0.15, sigma_read = 0.10, ADC = 3 bits
        selected_cases = [
            ("programming_variation", "0.15", "Prog. Noise $\sigma=0.15$", "#2ca02c"),
            ("read_noise", "0.1", "Read Noise $\sigma=0.10$", "#d62728"),
            ("adc_quantization", "3", "3-Bit ADC", "#9467bd"),
            ("stuck_at_faults", "0.05", "5% Stuck-At Faults", "#8c564b"),
        ]

        for n_type, p_val, lbl, col in selected_cases:
            sub = m_df[(m_df.non_ideality_type == n_type) & (m_df.param_value == p_val)]
            if not sub.empty:
                # Bin by ideal margin
                margins = sub["ideal_margin"].values
                errors = sub["retrieval_error"].values
                bins = np.linspace(0.0, float(np.percentile(margins, 98)), 8)
                bin_centers = 0.5 * (bins[:-1] + bins[1:])
                bin_err_rates = []
                for b_lo, b_hi in zip(bins[:-1], bins[1:]):
                    in_bin = (margins >= b_lo) & (margins < b_hi)
                    if in_bin.sum() > 0:
                        bin_err_rates.append(float(errors[in_bin].mean()))
                    else:
                        bin_err_rates.append(np.nan)
                ax1.plot(bin_centers, bin_err_rates, marker="o", label=lbl, color=col, lw=2)

        ax1.set_title("(a) Retrieval Error Probability vs. Ideal Similarity Margin")
        ax1.set_xlabel("Ideal Similarity Margin $\Delta s = s_{(1)} - s_{(2)}$")
        ax1.set_ylabel("Probability of Retrieval Flip under Non-Ideality")
        ax1.legend(frameon=True)
        ax1.set_ylim(-0.02, 1.02)

        # Subplot 2: ROC Curves for Error Prediction from Margin
        for n_type, p_val, lbl, col in selected_cases:
            sub = m_df[(m_df.non_ideality_type == n_type) & (m_df.param_value == p_val)]
            if not sub.empty:
                y_true = sub["retrieval_error"].values
                scores = -sub["ideal_margin"].values
                if 0 < y_true.sum() < len(y_true):
                    fpr, tpr, _ = roc_curve(y_true, scores)
                    auc = roc_auc_score(y_true, scores)
                    ax2.plot(fpr, tpr, label=f"{lbl} (AUC = {auc:.3f})", color=col, lw=2)

        ax2.plot([0, 1], [0, 1], "k--", alpha=0.5, label="Random Guess (AUC = 0.500)")
        ax2.set_title("(b) ROC Curves: Predicting Retrieval Failure from Margin")
        ax2.set_xlabel("False Positive Rate")
        ax2.set_ylabel("True Positive Rate")
        ax2.legend(frameon=True, loc="lower right")

        plt.tight_layout()
        fig_path2 = OUT / "fig_margin_error_relationship.png"
        plt.savefig(fig_path2, dpi=300)
        plt.close()
        print(f"Saved {fig_path2}")


if __name__ == "__main__":
    main()
