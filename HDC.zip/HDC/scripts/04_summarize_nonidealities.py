"""
Aggregate Stage 5 & 6 non-ideality and similarity-margin results.
Computes summary statistics (mean ± std, 95% Student-t CI over trials),
AUROC for margin-based error prediction, and produces markdown summaries and CSV tables.

Usage:
  python scripts/04_summarize_nonidealities.py [results_dir]
"""
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "results" / "stage5"

def ci(x, conf=0.95):
    x = np.asarray(x, float)
    n = len(x)
    m = float(x.mean())
    s = float(x.std(ddof=1)) if n > 1 else 0.0
    h = float(stats.t.ppf(0.5 + conf / 2, n - 1) * s / np.sqrt(n)) if n > 1 else 0.0
    return m, s, m - h, m + h


def main():
    raw_path = OUT / "raw_nonideality_results.jsonl"
    if not raw_path.exists():
        print(f"Error: {raw_path} not found. Run 03_run_nonideality_experiments.py first.")
        sys.exit(1)

    rows = [json.loads(line) for line in open(raw_path)]
    df = pd.DataFrame(rows)

    # 1. Aggregate over MC trials per split trial first (to get per-trial mean), then over trials
    # Group by (task, model, non_ideality_type, param_name, param_value, trial)
    trial_means = df.groupby(
        ["task", "model", "non_ideality_type", "param_name", "param_value", "trial"],
        as_index=False
    ).agg({
        "macro_f1": "mean",
        "balanced_accuracy": "mean",
        "accuracy": "mean",
        "retrieval_error_rate": "mean",
    })

    summary_rows = []
    metrics = ["macro_f1", "balanced_accuracy", "accuracy", "retrieval_error_rate"]

    for (task, model, n_type, p_name, p_val), g in trial_means.groupby(
        ["task", "model", "non_ideality_type", "param_name", "param_value"]
    ):
        rec = {
            "task": task,
            "model": model,
            "non_ideality_type": n_type,
            "param_name": p_name,
            "param_value": p_val,
            "n_trials": len(g),
        }
        for m in metrics:
            mean, sd, lo, hi = ci(g[m])
            rec.update({
                f"{m}_mean": mean,
                f"{m}_std": sd,
                f"{m}_ci_lo": lo,
                f"{m}_ci_hi": hi,
            })
        summary_rows.append(rec)

    sum_df = pd.DataFrame(summary_rows)
    sum_df.to_csv(OUT / "nonideality_summary.csv", index=False)

    # 2. Margin Analysis (Stage 6)
    margin_path = OUT / "margin_records.jsonl"
    margin_summary = []
    if margin_path.exists():
        m_rows = [json.loads(line) for line in open(margin_path)]
        m_df = pd.DataFrame(m_rows)

        # For each non-ideality sweep condition, compute ROC AUC of predicting retrieval error from (negative) ideal margin
        for (n_type, p_val), mg in m_df.groupby(["non_ideality_type", "param_value"]):
            y_true_retrieval = mg["retrieval_error"].values
            y_true_task = mg["task_error"].values
            margins = mg["ideal_margin"].values

            # Higher error when margin is small -> score = -margin
            scores = -margins
            n_retrieval_errors = int(y_true_retrieval.sum())
            n_total = len(y_true_retrieval)

            # AUROC only valid if both classes exist (at least one error and one non-error)
            if 0 < n_retrieval_errors < n_total:
                auc_retrieval = float(roc_auc_score(y_true_retrieval, scores))
            else:
                auc_retrieval = np.nan

            auc_task = float(roc_auc_score(y_true_task, scores)) if 0 < y_true_task.sum() < n_total else np.nan

            margin_summary.append({
                "non_ideality_type": n_type,
                "param_value": p_val,
                "n_samples": n_total,
                "retrieval_error_count": n_retrieval_errors,
                "retrieval_error_rate": float(n_retrieval_errors / n_total),
                "auroc_margin_vs_retrieval_error": auc_retrieval,
                "auroc_margin_vs_task_error": auc_task,
            })

        m_sum_df = pd.DataFrame(margin_summary)
        m_sum_df.to_csv(OUT / "margin_analysis_summary.csv", index=False)

    # 3. Generate Markdown Report
    md = [
        "# Stage 5 & 6 Results: Hardware Non-Idealities & Retrieval Margin Analysis\n",
        "Evaluated on held-out test sets across 10 repeated stratified splits (white wine dataset, deduplicated protocol).\n",
        "## 1. Non-Ideality Robustness Sweeps (Task = Original 7-class Quality)\n",
    ]

    for model in ["hdc_single", "hdc_retrain"]:
        model_title = "HDC Single-Pass (Binary AM)" if model == "hdc_single" else "HDC + Retraining (Binary AM)"
        md.append(f"### Model: {model_title}\n")

        for n_type in ["ideal", "programming_variation", "read_noise", "adc_quantization", "stuck_at_faults"]:
            sub = sum_df[(sum_df.task == "original") & (sum_df.model == model) & (sum_df.non_ideality_type == n_type)]
            if sub.empty:
                continue

            md.append(f"#### Non-Ideality: `{n_type}`\n")
            md.append("| Parameter | Value | Macro-F1 | Balanced Acc. | Accuracy | Retrieval Error Rate |")
            md.append("|---|---|---|---|---|---|")

            for _, r in sub.iterrows():
                p_str = f"{r['param_name']} = {r['param_value']}" if r['param_name'] != 'none' else "Ideal"
                f1 = f"{r['macro_f1_mean']:.3f} ± {r['macro_f1_std']:.3f}"
                bacc = f"{r['balanced_accuracy_mean']:.3f} ± {r['balanced_accuracy_std']:.3f}"
                acc = f"{r['accuracy_mean']:.3f} ± {r['accuracy_std']:.3f}"
                err = f"{r['retrieval_error_rate_mean']:.3f} ± {r['retrieval_error_rate_std']:.3f}"
                md.append(f"| {r['param_name']} | {r['param_value']} | {f1} | {bacc} | {acc} | {err} |")
            md.append("")

    if margin_summary:
        md.append("## 2. Research Question Analysis: Margin vs. Retrieval Reliability (Stage 6)\n")
        md.append("Hypothesis: *Can the similarity margin between highest- and second-highest-scoring classes predict retrieval errors under non-idealities?*\n")
        md.append("| Non-Ideality Type | Parameter Value | Total Queries | Retrieval Errors | Error Rate | AUROC (Predicting Retrieval Error from Margin) | AUROC (Predicting Task Error) |")
        md.append("|---|---|---|---|---|---|---|")
        for r in margin_summary:
            auc_r = f"{r['auroc_margin_vs_retrieval_error']:.3f}" if not np.isnan(r['auroc_margin_vs_retrieval_error']) else "N/A"
            auc_t = f"{r['auroc_margin_vs_task_error']:.3f}" if not np.isnan(r['auroc_margin_vs_task_error']) else "N/A"
            md.append(f"| {r['non_ideality_type']} | {r['param_value']} | {r['n_samples']} | {r['retrieval_error_count']} | {r['retrieval_error_rate']:.3f} | **{auc_r}** | {auc_t} |")
        md.append("")

    (OUT / "summary.md").write_text("\n".join(md), encoding="utf-8")
    print(f"Summary generated at {OUT / 'summary.md'}")


if __name__ == "__main__":
    main()
