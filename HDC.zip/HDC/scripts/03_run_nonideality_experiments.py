"""
Stage 5 & 6: Hardware-inspired non-ideality simulation and similarity-margin analysis.
Evaluates the impact of:
  1. Programming / Conductance Variation (sigma_prog)
  2. Read Noise (sigma_read)
  3. ADC Bit Resolution (adc_bits)
  4. Stuck-at Faults (p_saf)
on retrieval accuracy and examines the margin-reliability hypothesis across repeated splits.

Usage:
  python scripts/03_run_nonideality_experiments.py [--trials N] [--mc_trials M] [--out DIR]
"""
import argparse
import json
import sys
import time
from pathlib import Path
import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from hdcmem.data import load_wine, group_duplicates, make_split, to_task
from hdcmem.hdc import IDLevelEncoder, AssociativeMemory
from hdcmem.conductance import IdealDifferentialConductanceMemory, NonIdealDifferentialConductanceMemory
from hdcmem.metrics import evaluate, macro_f1


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(ROOT / "configs" / "experiment.yaml"))
    ap.add_argument("--trials", type=int, default=None)
    ap.add_argument("--mc_trials", type=int, default=None)
    ap.add_argument("--out", default=str(ROOT / "results" / "stage5"))
    return ap.parse_args()


def select_best_hdc(X, y_train, y_val, split, groups, U, D, scaling_grid, Q_grid, retrain_max_epochs, labels, hv_seed):
    """Find best scaling and Q on validation set using macro-F1."""
    best_single = None
    best_retrain = None

    y_tr_idx = np.searchsorted(labels, y_train)
    y_va_idx = np.searchsorted(labels, y_val)

    for scaling in scaling_grid:
        for Q in Q_grid:
            enc = IDLevelEncoder(X.shape[1], D, Q, scaling, hv_seed).fit(X[split.train])
            HU = enc.encode(U)
            Htr = HU[groups.inverse[split.train]].astype(np.float32)
            Hva = HU[groups.inverse[split.val]].astype(np.float32)

            am = AssociativeMemory(len(labels), D).fit(Htr, y_tr_idx)
            # Epoch 0: single pass
            v0 = macro_f1(y_va_idx, am.predict(Hva), list(range(len(labels))))
            if best_single is None or v0 > best_single["val_macro_f1"]:
                best_single = {
                    "scaling": scaling,
                    "Q": Q,
                    "epochs": 0,
                    "val_macro_f1": v0,
                    "prototypes": am.prototypes.copy(),
                    "encoder": enc,
                }

            # Retraining epochs
            cur_best_retrain = {"val_macro_f1": v0, "epochs": 0, "prototypes": am.prototypes.copy()}
            for e in range(1, retrain_max_epochs + 1):
                am.retrain_epoch(Htr, y_tr_idx)
                ve = macro_f1(y_va_idx, am.predict(Hva), list(range(len(labels))))
                if ve > cur_best_retrain["val_macro_f1"]:
                    cur_best_retrain = {"val_macro_f1": ve, "epochs": e, "prototypes": am.prototypes.copy()}

            if best_retrain is None or cur_best_retrain["val_macro_f1"] > best_retrain["val_macro_f1"]:
                best_retrain = {
                    "scaling": scaling,
                    "Q": Q,
                    "epochs": cur_best_retrain["epochs"],
                    "val_macro_f1": cur_best_retrain["val_macro_f1"],
                    "prototypes": cur_best_retrain["prototypes"].copy(),
                    "encoder": enc,
                }

    return {"hdc_single": best_single, "hdc_retrain": best_retrain}


def main():
    args = parse_args()
    cfg = yaml.safe_load(open(args.config))
    OUT = Path(args.out)
    OUT.mkdir(parents=True, exist_ok=True)

    n_trials = args.trials or cfg["split"]["n_trials"]
    hw_cfg = cfg["hardware"]
    n_mc = args.mc_trials or hw_cfg.get("n_mc_trials", 10)

    ds = cfg["dataset"]["primary"]
    X, y, feats = load_wine(ROOT / cfg["dataset"]["paths"][ds])
    groups = group_duplicates(X, y)
    U = X[groups.first_idx]
    D = cfg["hdc"]["D"]

    labels_by_task = {
        "original": sorted(np.unique(y).tolist()),
        "grouped3": [0, 1, 2],
    }

    results_file = OUT / "raw_nonideality_results.jsonl"
    margins_file = OUT / "margin_records.jsonl"

    t0 = time.time()
    print(f"Starting Stage 5 & 6 Non-Ideality Experiments (Trials: {n_trials}, MC: {n_mc})...")

    with open(results_file, "w") as f_res, open(margins_file, "w") as f_marg:
        for protocol in ["dedup"]:  # Primary deduplicated protocol
            for trial in range(n_trials):
                split_seed = cfg["split"]["split_seed_base"] + trial
                hv_seed = cfg["split"]["hv_seed_base"] + trial
                split = make_split(y, groups, split_seed, protocol, tuple(cfg["split"]["fractions"]))

                for task in cfg["tasks"]:
                    y_task = to_task(y, task)
                    labels = labels_by_task[task]
                    y_tr = y_task[split.train]
                    y_va = y_task[split.val]
                    y_te = y_task[split.test]
                    y_te_idx = np.searchsorted(labels, y_te)

                    # Fit & select best HDC models
                    best_models = select_best_hdc(
                        X, y_tr, y_va, split, groups, U, D,
                        cfg["hdc"]["scaling_grid"], cfg["hdc"]["Q_grid"],
                        cfg["hdc"]["retrain_max_epochs"], labels, hv_seed
                    )

                    for model_name, model_info in best_models.items():
                        enc = model_info["encoder"]
                        prototypes = model_info["prototypes"]

                        # Encode test records
                        HU = enc.encode(U)
                        Hte = HU[groups.inverse[split.test]].astype(np.int8)

                        # 1. Ideal Baseline Reference
                        ideal_mem = IdealDifferentialConductanceMemory(prototypes)
                        ideal_scores = np.array([ideal_mem.differential_current(q, mode="normalized") for q in Hte])
                        ideal_preds = ideal_scores.argmax(axis=1)

                        # Ideal margins: top1 - top2
                        sorted_sc = np.sort(ideal_scores, axis=1)[:, ::-1]
                        ideal_margins = sorted_sc[:, 0] - sorted_sc[:, 1]

                        ideal_eval = evaluate(y_te_idx, ideal_preds, list(range(len(labels))))
                        base_rec = {
                            "trial": trial,
                            "protocol": protocol,
                            "task": task,
                            "model": model_name,
                            "non_ideality_type": "ideal",
                            "param_name": "none",
                            "param_value": 0.0,
                            "mc_trial": 0,
                            "n_test": len(Hte),
                            **ideal_eval,
                        }
                        f_res.write(json.dumps(base_rec) + "\n")

                        # Helper function to evaluate and log non-ideal condition
                        def test_and_log(non_ideal_type, param_name, param_val, mem_factory):
                            for mc in range(n_mc):
                                mc_seed = (trial * 10000) + (mc * 100) + int(abs(hash(str(param_val))) % 99)
                                mem = mem_factory(mc_seed)
                                noisy_scores = mem.scores_batch(Hte)
                                noisy_preds = noisy_scores.argmax(axis=1)

                                ev = evaluate(y_te_idx, noisy_preds, list(range(len(labels))))
                                retrieval_error_rate = float(np.mean(noisy_preds != ideal_preds))

                                rec = {
                                    "trial": trial,
                                    "protocol": protocol,
                                    "task": task,
                                    "model": model_name,
                                    "non_ideality_type": non_ideal_type,
                                    "param_name": param_name,
                                    "param_value": param_val if param_val is not None else "none",
                                    "mc_trial": mc,
                                    "retrieval_error_rate": retrieval_error_rate,
                                    "n_test": len(Hte),
                                    **ev,
                                }
                                f_res.write(json.dumps(rec) + "\n")

                                # Save query-level margins and error indicators for key representative sweeps
                                if mc == 0 and task == "original" and model_name == "hdc_single":
                                    is_retrieval_error = (noisy_preds != ideal_preds).astype(int)
                                    is_task_error = (noisy_preds != y_te_idx).astype(int)
                                    for qi in range(len(Hte)):
                                        f_marg.write(json.dumps({
                                            "trial": trial,
                                            "query_idx": qi,
                                            "ideal_margin": float(ideal_margins[qi]),
                                            "ideal_top1": int(ideal_preds[qi]),
                                            "true_class": int(y_te_idx[qi]),
                                            "non_ideality_type": non_ideal_type,
                                            "param_value": str(param_val),
                                            "retrieval_error": int(is_retrieval_error[qi]),
                                            "task_error": int(is_task_error[qi]),
                                        }) + "\n")

                        # 2. Sweep Programming Variation (sigma_prog)
                        for sp in hw_cfg["sigma_prog_grid"]:
                            if sp == 0.0:
                                continue
                            test_and_log(
                                "programming_variation", "sigma_prog", sp,
                                lambda s, sp=sp: NonIdealDifferentialConductanceMemory(prototypes, sigma_prog=sp, seed=s)
                            )

                        # 3. Sweep Read Noise (sigma_read)
                        for sr in hw_cfg["sigma_read_grid"]:
                            if sr == 0.0:
                                continue
                            test_and_log(
                                "read_noise", "sigma_read", sr,
                                lambda s, sr=sr: NonIdealDifferentialConductanceMemory(prototypes, sigma_read=sr, seed=s)
                            )

                        # 4. Sweep ADC Quantization (adc_bits)
                        for bits in hw_cfg["adc_bits_grid"]:
                            if bits is None:
                                continue
                            test_and_log(
                                "adc_quantization", "adc_bits", bits,
                                lambda s, b=bits: NonIdealDifferentialConductanceMemory(prototypes, adc_bits=b, seed=s)
                            )

                        # 5. Sweep Stuck-at Faults (p_saf)
                        for ps in hw_cfg["p_saf_grid"]:
                            if ps == 0.0:
                                continue
                            test_and_log(
                                "stuck_at_faults", "p_saf", ps,
                                lambda s, ps=ps: NonIdealDifferentialConductanceMemory(prototypes, p_saf=ps, seed=s)
                            )

                f_res.flush()
                f_marg.flush()
                print(f"[{time.time()-t0:6.1f}s] Trial {trial+1}/{n_trials} completed for all non-ideality sweeps", flush=True)

    print(f"Stage 5 & 6 experiments complete in {time.time()-t0:.1f}s. Results written to {OUT}")


if __name__ == "__main__":
    main()
