"""
Ideal differential-conductance memory for HDC.

Mathematical model (Stage 4B):
  - Binary class prototypes w ∈ {-1, +1}^D mapped to differential conductance pairs.
  - Mapping: w_j = +1 → (g_+,j, g_-,j) = (1, 0); w_j = -1 → (g_+,j, g_-,j) = (0, 1).
  - Query hypervector q ∈ {-1, +1}^D applied to crossbar rows.
  - Ideal differential column current: I_k ∝ sum_j q_j (g_+,kj - g_-,kj) = q · w_k
  - Cosine similarity score: s_k = (q · w_k) / D, where D = ||q||^2 = ||w_k||^2.

Assumptions (to be distinguished from physical hardware):
  - Bipolar query and prototype vectors (exactly ±1).
  - Read voltage V_rd uniform across rows.
  - Differential transimpedance: I_k → V_k with constant gain.
  - No non-idealities (noise, variation, quantisation): Stage 5 introduces these.
  - Current summation is exact (no truncation).
  - Score normalisation by D is exact.

This module implements:
  1. IdealDifferentialConductanceMemory: stores binary prototypes, converts to (g_+, g_-) pairs.
  2. score() method: computes ideal differential scores (proportional to dot products).
  3. predict() method: ranks by score, returns class predictions.
  4. Equivalence tests verify: software dot product = hardware differential score.
"""
from __future__ import annotations
import numpy as np


class IdealDifferentialConductanceMemory:
    """
    Binary class-prototype associative memory, represented as differential conductance pairs.
    
    Storage:
      - self.prototypes: (K, D) binary hypervectors, shape of class prototypes.
      - self.g_plus:  (K, D) conductance on positive line; g_plus[k,j] ∈ {0, 1}.
      - self.g_minus: (K, D) conductance on negative line; g_minus[k,j] ∈ {0, 1}.
    
    Invariant: For each (k, j), exactly one of g_plus[k,j] or g_minus[k,j] is 1.
    """

    def __init__(self, prototypes: np.ndarray):
        """
        Initialize from binary prototypes.
        
        Args:
            prototypes: (K, D) array, dtype int8, values in {-1, +1}.
        """
        assert prototypes.dtype == np.int8 and set(np.unique(prototypes)) == {-1, 1}, \
            "prototypes must be bipolar (int8, values {-1, +1})"
        self.prototypes = prototypes.copy()
        self.K, self.D = prototypes.shape

        # Map to differential conductance: normalize to [0, 1].
        # w = +1 -> (g_+, g_-) = (1, 0)
        # w = -1 -> (g_+, g_-) = (0, 1)
        self.g_plus = np.where(prototypes == 1, 1.0, 0.0).astype(np.float64)
        self.g_minus = np.where(prototypes == -1, 1.0, 0.0).astype(np.float64)

        # Verify invariant.
        assert np.allclose(self.g_plus + self.g_minus, 1.0), \
            "conductance invariant violated: g_+ + g_- must be 1 everywhere"

    def _verify_query(self, q: np.ndarray):
        """Assert query is bipolar."""
        assert q.ndim == 1 and q.shape[0] == self.D, \
            f"query shape mismatch: expected ({self.D},), got {q.shape}"
        assert set(np.unique(q)) == {-1, 1}, \
            "query must be bipolar (values {-1, +1})"

    def differential_current(self, q: np.ndarray, mode: str = "exact") -> np.ndarray:
        """
        Compute ideal differential column current (or proportional score).
        
        Physical interpretation (ideal, no noise):
          I_k = integral of [q_j * (g_+,kj - g_-,kj) * V_rd * dt] summed over rows j.
          Under uniform V_rd and constant integration time: I_k ∝ sum_j q_j * (g_+,kj - g_-,kj).
        
        Args:
            q: (D,) bipolar query hypervector.
            mode: 'exact' -> return exact proportional current; 'normalized' -> divide by D (cosine sim.).
        
        Returns:
            (K,) array of differential scores (one per class).
        """
        self._verify_query(q)
        q_float = q.astype(np.float64)
        # I_k = sum_j q_j * (g_+,kj - g_-,kj)
        diff_cond = self.g_plus - self.g_minus  # (K, D), values in {-1, 0, +1}
        I = q_float @ diff_cond.T  # (K,)
        if mode == "exact":
            return I
        elif mode == "normalized":
            return I / self.D
        else:
            raise ValueError(f"unknown mode: {mode}")

    def dot_product_software(self, q: np.ndarray) -> np.ndarray:
        """
        Software reference: dot products between query and prototypes.
        
        This is what the software HDC computes:
          dot_k = q · prototypes[k] for each class k.
        
        Args:
            q: (D,) bipolar query.
        
        Returns:
            (K,) array of dot products.
        """
        self._verify_query(q)
        return q.astype(np.float64) @ self.prototypes.astype(np.float64).T  # (K,)

    def cosine_similarity_software(self, q: np.ndarray) -> np.ndarray:
        """
        Software reference: cosine similarity between query and prototypes.
        
        For bipolar vectors: cos(q, p_k) = (q · p_k) / (||q|| * ||p_k||) = (q · p_k) / D.
        
        Args:
            q: (D,) bipolar query.
        
        Returns:
            (K,) array of cosine similarities.
        """
        return self.dot_product_software(q) / self.D

    def scores(self, q: np.ndarray, mode: str = "differential") -> np.ndarray:
        """
        Compute scores for a query (hardware or software).
        
        Args:
            q: (D,) bipolar query.
            mode: 'differential' -> ideal hardware differential current;
                  'dot_product' -> software dot product (for validation);
                  'cosine' -> software cosine similarity (for validation).
        
        Returns:
            (K,) scores, one per class.
        """
        if mode == "differential":
            return self.differential_current(q, mode="exact")
        elif mode == "dot_product":
            return self.dot_product_software(q)
        elif mode == "cosine":
            return self.cosine_similarity_software(q)
        else:
            raise ValueError(f"unknown mode: {mode}")

    def predict(self, q: np.ndarray, mode: str = "differential") -> int:
        """
        Predict class for a query by argmax score.
        
        Args:
            q: (D,) bipolar query.
            mode: as in scores().
        
        Returns:
            Predicted class index (0 to K-1).
        """
        return self.scores(q, mode).argmax()

    def predict_batch(self, Q: np.ndarray, mode: str = "differential") -> np.ndarray:
        """
        Predict classes for a batch of queries.
        
        Args:
            Q: (N, D) array of N bipolar queries.
            mode: as in scores().
        
        Returns:
            (N,) array of predicted class indices.
        """
        assert Q.ndim == 2 and Q.shape[1] == self.D, \
            f"query batch shape mismatch: expected (?, {self.D}), got {Q.shape}"
        predictions = np.zeros(len(Q), dtype=np.int64)
        for i, q in enumerate(Q):
            predictions[i] = self.predict(q, mode)
        return predictions

    def equivalence_error(self, q: np.ndarray) -> dict:
        """
        Diagnostic: compare hardware (differential) and software (dot product) scores.
        
        Under the ideal mapping, differential_current(q) should equal dot_product_software(q).
        
        Args:
            q: (D,) bipolar query.
        
        Returns:
            dict with keys:
              - 'hardware_score': differential current I_k for each class.
              - 'software_dot': software dot product for each class.
              - 'absolute_error': |hardware - software| for each class.
              - 'relative_error': |hardware - software| / |software| for each class (avoid div by 0).
              - 'max_abs_error': maximum absolute error across all classes.
              - 'max_rel_error': maximum relative error (excluding division by zero cases).
        """
        hardware = self.differential_current(q, mode="exact")
        software = self.dot_product_software(q)
        abs_err = np.abs(hardware - software)
        # Relative error: handle division by zero gracefully.
        rel_err = np.full_like(abs_err, np.inf)
        nonzero = np.abs(software) > 0
        rel_err[nonzero] = abs_err[nonzero] / np.abs(software[nonzero])
        return {
            "hardware_score": hardware,
            "software_dot": software,
            "absolute_error": abs_err,
            "relative_error": rel_err,
            "max_abs_error": float(abs_err.max()),
            "max_rel_error": float(rel_err[rel_err != np.inf].max()) if np.any(rel_err != np.inf) else 0.0,
        }


class NonIdealDifferentialConductanceMemory:
    """
    Hardware-inspired non-ideal differential conductance associative memory for HDC.

    Simulates four physical memory crossbar non-idealities:
      1. Programming Variation (Device-to-Device):
         Conductance values diverge from ideal target levels (0 or 1) due to filamentary
         stochasticity during device programming:
             g~_plus  = clip(g_plus  + N(0, sigma_prog^2), 0.0, 1.0)
             g~_minus = clip(g_minus + N(0, sigma_prog^2), 0.0, 1.0)
         This variation is static across queries for a given programmed array.

      2. Stuck-at Faults (Defects):
         A fraction p_saf of cells are defective, stuck at HRS (0.0) with probability
         saf_ratio_hrs or LRS (1.0) with probability (1 - saf_ratio_hrs).

      3. Read Noise (Cycle-to-Cycle / Temporal):
         Thermal and flicker noise in the crosspoint cells and readout circuitry causes
         instantaneous column current fluctuations during each query read:
             I~_k = I_k + N(0, (sigma_read * sqrt(D))^2)
         In normalized score terms (s_k = I_k / D):
             s~_k = s_k + N(0, (sigma_read / sqrt(D))^2)

      4. ADC Output Quantization:
         Column current is digitized by an analog-to-digital converter with adc_bits resolution
         over the operational range [-1, +1] in normalized score space:
             Delta = 2 / (2^B - 1)
             s~_k^(Q) = round((s~_k + 1) / Delta) * Delta - 1
    """

    def __init__(
        self,
        prototypes: np.ndarray,
        sigma_prog: float = 0.0,
        sigma_read: float = 0.0,
        adc_bits: int | None = None,
        p_saf: float = 0.0,
        saf_ratio_hrs: float = 0.5,
        seed: int | np.random.Generator | None = None,
    ):
        """
        Initialize non-ideal differential conductance memory.

        Args:
            prototypes: (K, D) array, dtype int8, values in {-1, +1}.
            sigma_prog: Standard deviation of programming variation (normalized to [0, 1] conductance).
            sigma_read: Standard deviation of single-crosspoint read noise.
            adc_bits: ADC bit resolution for column score readout (None for continuous / ideal).
            p_saf: Probability of stuck-at fault per memristor device.
            saf_ratio_hrs: Fraction of stuck-at defects that are stuck-at-HRS (0.0).
            seed: Random seed or NumPy Generator for reproducible hardware instances.
        """
        assert prototypes.dtype == np.int8 and set(np.unique(prototypes)) == {-1, 1}, \
            "prototypes must be bipolar (int8, values {-1, +1})"
        self.prototypes = prototypes.copy()
        self.K, self.D = prototypes.shape

        self.sigma_prog = float(sigma_prog)
        self.sigma_read = float(sigma_read)
        self.adc_bits = int(adc_bits) if adc_bits is not None else None
        self.p_saf = float(p_saf)
        self.saf_ratio_hrs = float(saf_ratio_hrs)

        if isinstance(seed, np.random.Generator):
            self.rng = seed
        else:
            self.rng = np.random.default_rng(seed)

        # 1. Base ideal conductances
        self.g_plus = np.where(prototypes == 1, 1.0, 0.0).astype(np.float64)
        self.g_minus = np.where(prototypes == -1, 1.0, 0.0).astype(np.float64)

        # 2. Apply static programming variation if sigma_prog > 0
        if self.sigma_prog > 0.0:
            noise_plus = self.rng.normal(0.0, self.sigma_prog, size=(self.K, self.D))
            noise_minus = self.rng.normal(0.0, self.sigma_prog, size=(self.K, self.D))
            self.g_plus = np.clip(self.g_plus + noise_plus, 0.0, 1.0)
            self.g_minus = np.clip(self.g_minus + noise_minus, 0.0, 1.0)

        # 3. Apply static stuck-at faults if p_saf > 0
        if self.p_saf > 0.0:
            # Mask of affected devices in g_plus and g_minus arrays
            mask_plus = self.rng.random(size=(self.K, self.D)) < self.p_saf
            mask_minus = self.rng.random(size=(self.K, self.D)) < self.p_saf

            val_plus = np.where(self.rng.random(size=(self.K, self.D)) < self.saf_ratio_hrs, 0.0, 1.0)
            val_minus = np.where(self.rng.random(size=(self.K, self.D)) < self.saf_ratio_hrs, 0.0, 1.0)

            self.g_plus[mask_plus] = val_plus[mask_plus]
            self.g_minus[mask_minus] = val_minus[mask_minus]

        # Precompute static effective differential conductance weight matrix
        self.diff_cond = (self.g_plus - self.g_minus)  # Shape (K, D)

    def _quantize_scores(self, s: np.ndarray) -> np.ndarray:
        """Apply uniform ADC quantization to scores in [-1, +1]."""
        if self.adc_bits is None:
            return s
        num_levels = 2 ** self.adc_bits
        delta = 2.0 / (num_levels - 1)
        s_clipped = np.clip(s, -1.0, 1.0)
        quantized = np.round((s_clipped + 1.0) / delta) * delta - 1.0
        return quantized

    def scores_batch(self, Q: np.ndarray, rng: np.random.Generator | None = None) -> np.ndarray:
        """
        Compute noisy scores for a batch of query hypervectors.

        Args:
            Q: (N, D) array of bipolar query hypervectors in {-1, +1}.
            rng: Optional per-query random generator for temporal read noise.

        Returns:
            (N, K) array of normalized scores.
        """
        assert Q.ndim == 2 and Q.shape[1] == self.D, \
            f"query batch shape mismatch: expected (?, {self.D}), got {Q.shape}"
        N = Q.shape[0]
        Q_float = Q.astype(np.float64)

        # Ideal MAC product with programmed differential conductance: (N, K)
        # s_unquant = (Q @ diff_cond^T) / D
        s = (Q_float @ self.diff_cond.T) / self.D

        # Add temporal cycle-to-cycle read noise
        if self.sigma_read > 0.0:
            r = rng if rng is not None else self.rng
            # Column score noise std = sigma_read / sqrt(D)
            read_noise = r.normal(0.0, self.sigma_read / np.sqrt(self.D), size=(N, self.K))
            s = s + read_noise

        # Apply ADC quantization if configured
        if self.adc_bits is not None:
            s = self._quantize_scores(s)

        return s

    def scores(self, q: np.ndarray, rng: np.random.Generator | None = None) -> np.ndarray:
        """Compute noisy scores for a single query hypervector."""
        assert q.ndim == 1 and q.shape[0] == self.D, \
            f"query shape mismatch: expected ({self.D},), got {q.shape}"
        return self.scores_batch(q[np.newaxis, :], rng=rng)[0]

    def predict_batch(self, Q: np.ndarray, rng: np.random.Generator | None = None) -> np.ndarray:
        """Predict class indices for a batch of queries."""
        return self.scores_batch(Q, rng=rng).argmax(axis=1)

    def predict(self, q: np.ndarray, rng: np.random.Generator | None = None) -> int:
        """Predict class index for a single query."""
        return int(self.scores(q, rng=rng).argmax())

    def similarity_margins_batch(self, Q: np.ndarray, rng: np.random.Generator | None = None) -> dict:
        """
        Compute top-1 and top-2 scores, class indices, and similarity margins for a batch of queries.

        Margin definition:
            Delta s_i = s_(1),i - s_(2),i  (difference between top-1 and top-2 class scores)

        Returns:
            dict with keys:
              - 'margins': (N,) array of Delta s
              - 'top1_classes': (N,) array of top-1 class indices
              - 'top2_classes': (N,) array of top-2 class indices
              - 'top1_scores': (N,) array of top-1 scores
              - 'top2_scores': (N,) array of top-2 scores
              - 'scores': (N, K) full score matrix
        """
        S = self.scores_batch(Q, rng=rng)  # (N, K)
        # Sort scores along class axis in descending order
        sorted_indices = np.argsort(-S, axis=1)
        top1_idx = sorted_indices[:, 0]
        top2_idx = sorted_indices[:, 1]

        top1_sc = np.take_along_axis(S, top1_idx[:, np.newaxis], axis=1).squeeze(1)
        top2_sc = np.take_along_axis(S, top2_idx[:, np.newaxis], axis=1).squeeze(1)
        margins = top1_sc - top2_sc

        return {
            "margins": margins,
            "top1_classes": top1_idx,
            "top2_classes": top2_idx,
            "top1_scores": top1_sc,
            "top2_scores": top2_sc,
            "scores": S,
        }
