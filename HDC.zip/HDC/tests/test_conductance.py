import sys
from pathlib import Path
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from hdcmem.conductance import IdealDifferentialConductanceMemory, NonIdealDifferentialConductanceMemory
from hdcmem.hdc import random_bipolar, IDLevelEncoder, AssociativeMemory
from hdcmem.data import load_wine, group_duplicates, make_split

D = 10000


# ---------- Stage 4C: Ideal conductance mapping validation ----------

def test_conductance_encoding_invariants():
    """Verify that bipolar weights are correctly encoded into differential conductance pairs."""
    prototypes = np.array([
        [ 1, -1,  1, -1],
        [-1,  1, -1,  1],
    ], dtype=np.int8)

    mem = IdealDifferentialConductanceMemory(prototypes)

    # Invariant 1: +1 -> (1, 0), -1 -> (0, 1)
    expected_g_plus = np.array([[1.0, 0.0, 1.0, 0.0], [0.0, 1.0, 0.0, 1.0]])
    expected_g_minus = np.array([[0.0, 1.0, 0.0, 1.0], [1.0, 0.0, 1.0, 0.0]])

    assert np.array_equal(mem.g_plus, expected_g_plus)
    assert np.array_equal(mem.g_minus, expected_g_minus)

    # Invariant 2: g_+ + g_- == 1 everywhere
    assert np.all(mem.g_plus + mem.g_minus == 1.0)

    # Invariant 3: g_+ - g_- == prototypes
    assert np.array_equal(mem.g_plus - mem.g_minus, prototypes)


def test_toy_deterministic_calculation():
    """Small hand-calculable example (K=3, D=4)."""
    prototypes = np.array([
        [ 1,  1,  1,  1],  # class 0: all +1
        [ 1, -1,  1, -1],  # class 1: alternating
        [-1,  1, -1,  1],  # class 2: opposite alternating
    ], dtype=np.int8)
    mem = IdealDifferentialConductanceMemory(prototypes)

    query = np.array([1, -1, 1, -1], dtype=np.int8)

    # Expected dot products:
    # dot(q, p0) = 1*1 + (-1)*1 + 1*1 + (-1)*1 = 0
    # dot(q, p1) = 1*1 + (-1)*(-1) + 1*1 + (-1)*(-1) = 4
    # dot(q, p2) = 1*(-1) + (-1)*1 + 1*(-1) + (-1)*1 = -4
    expected_currents = np.array([0.0, 4.0, -4.0])
    expected_normalized = np.array([0.0, 1.0, -1.0])

    exact_currents = mem.differential_current(query, mode="exact")
    norm_currents = mem.differential_current(query, mode="normalized")

    assert np.allclose(exact_currents, expected_currents, atol=1e-12)
    assert np.allclose(norm_currents, expected_normalized, atol=1e-12)
    assert mem.predict(query) == 1


def test_random_high_dim_exact_equivalence():
    """Verify exact equivalence on random D=10,000 hypervectors over K=7 classes."""
    rng = np.random.default_rng(42)
    K = 7
    prototypes = random_bipolar(rng, (K, D))
    mem = IdealDifferentialConductanceMemory(prototypes)

    n_queries = 50
    queries = random_bipolar(rng, (n_queries, D))

    for i in range(n_queries):
        q = queries[i]
        diag = mem.equivalence_error(q)
        assert diag["max_abs_error"] == 0.0, f"Absolute error non-zero on query {i}: {diag['max_abs_error']}"

        # Test cosine similarity equivalence
        cos_sw = mem.cosine_similarity_software(q)
        cos_hw = mem.differential_current(q, mode="normalized")
        assert np.allclose(cos_sw, cos_hw, atol=1e-12)

        # Test prediction equality
        pred_hw = mem.predict(q, mode="differential")
        pred_sw = mem.predict(q, mode="dot_product")
        pred_cos = mem.predict(q, mode="cosine")
        assert pred_hw == pred_sw == pred_cos

    # Test batch predictions
    batch_hw = mem.predict_batch(queries, mode="differential")
    batch_sw = mem.predict_batch(queries, mode="dot_product")
    assert np.array_equal(batch_hw, batch_sw)


def test_trained_model_wine_test_set_equivalence():
    """Verify exact equivalence using actual trained prototypes and test rows from wine dataset."""
    X, y, _ = load_wine(ROOT / "data" / "winequality-white.csv")
    g = group_duplicates(X, y)
    labels = sorted(np.unique(y).tolist())
    label_to_idx = {lb: i for i, lb in enumerate(labels)}
    y_idx = np.array([label_to_idx[yi] for yi in y])

    sp = make_split(y, g, seed=0, protocol="dedup")
    X_tr, y_tr = X[sp.train], y_idx[sp.train]
    X_te, y_te = X[sp.test], y_idx[sp.test]

    encoder = IDLevelEncoder(n_features=11, D=D, Q=32, scaling="minmax", seed=1000).fit(X_tr)
    H_tr = encoder.encode(X_tr)
    H_te = encoder.encode(X_te)

    am = AssociativeMemory(n_classes=len(labels), D=D).fit(H_tr, y_tr)
    sw_prototypes = am.prototypes  # binary prototypes {-1, +1}

    mem = IdealDifferentialConductanceMemory(sw_prototypes)

    # Software predictions
    sw_preds = am.predict(H_te, mode="binary")

    # Hardware differential memory predictions
    hw_preds = mem.predict_batch(H_te, mode="differential")

    assert np.array_equal(sw_preds, hw_preds), "Software and hardware predictions must be 100% identical under ideal conditions"

    # Verify score agreement on every sample in the test set (793 test samples)
    for i in range(len(H_te)):
        q = H_te[i]
        sw_scores = am.scores(H_te[i:i+1], mode="binary")[0]
        hw_scores = mem.differential_current(q, mode="normalized")
        assert np.allclose(sw_scores, hw_scores, atol=1e-6)


# ---------- Stage 5: Non-ideal conductance memory tests ----------

def test_non_ideal_zero_noise_equals_ideal():
    """Verify that NonIdealDifferentialConductanceMemory with zero noise matches Ideal memory exactly."""
    rng = np.random.default_rng(123)
    prototypes = random_bipolar(rng, (7, D))
    queries = random_bipolar(rng, (30, D))

    ideal_mem = IdealDifferentialConductanceMemory(prototypes)
    non_ideal_mem = NonIdealDifferentialConductanceMemory(
        prototypes,
        sigma_prog=0.0,
        sigma_read=0.0,
        adc_bits=None,
        p_saf=0.0,
        seed=123,
    )

    s_ideal = np.array([ideal_mem.differential_current(q, mode="normalized") for q in queries])
    s_non_ideal = non_ideal_mem.scores_batch(queries)

    assert np.allclose(s_ideal, s_non_ideal, atol=1e-12)
    assert np.array_equal(ideal_mem.predict_batch(queries), non_ideal_mem.predict_batch(queries))


def test_programming_variation_properties():
    """Verify programming noise clips to [0, 1] and degrades accuracy gracefully."""
    rng = np.random.default_rng(456)
    prototypes = random_bipolar(rng, (7, D))

    non_ideal_mem = NonIdealDifferentialConductanceMemory(
        prototypes,
        sigma_prog=0.2,
        seed=456,
    )

    # Ensure conductances stay physically bounded in [0, 1]
    assert np.all(non_ideal_mem.g_plus >= 0.0) and np.all(non_ideal_mem.g_plus <= 1.0)
    assert np.all(non_ideal_mem.g_minus >= 0.0) and np.all(non_ideal_mem.g_minus <= 1.0)
    # Ensure effective weights have deviated from pure {-1, +1}
    assert not np.array_equal(non_ideal_mem.diff_cond, prototypes)


def test_stuck_at_faults_discrete_values():
    """Verify stuck-at faults force affected memristors to exactly 0.0 or 1.0."""
    rng = np.random.default_rng(789)
    prototypes = random_bipolar(rng, (4, 1000))

    non_ideal_mem = NonIdealDifferentialConductanceMemory(
        prototypes,
        p_saf=0.10,
        saf_ratio_hrs=0.7,
        seed=789,
    )

    # All unperturbed conductances are 0.0 or 1.0; stuck-at faults must also be 0.0 or 1.0
    assert set(np.unique(non_ideal_mem.g_plus)).issubset({0.0, 1.0})
    assert set(np.unique(non_ideal_mem.g_minus)).issubset({0.0, 1.0})


def test_adc_quantization_levels():
    """Verify that B-bit ADC limits score resolution to at most 2^B levels."""
    rng = np.random.default_rng(999)
    prototypes = random_bipolar(rng, (5, 5000))
    queries = random_bipolar(rng, (50, 5000))

    # 3-bit ADC -> 8 discrete levels in [-1, +1]
    mem_3bit = NonIdealDifferentialConductanceMemory(prototypes, adc_bits=3, seed=999)
    scores = mem_3bit.scores_batch(queries)

    unique_levels = np.unique(np.round(scores, 5))
    assert len(unique_levels) <= 8
    # Levels must be evenly spaced by 2 / (8 - 1) = 2/7 ≈ 0.28571
    expected_step = 2.0 / 7.0
    diffs = np.diff(np.sort(unique_levels))
    if len(diffs) > 0:
        assert np.allclose(diffs % expected_step, 0.0, atol=1e-4) or np.allclose(diffs, expected_step, atol=1e-4)


def test_similarity_margins_batch():
    """Verify similarity margin computation."""
    rng = np.random.default_rng(111)
    prototypes = random_bipolar(rng, (5, D))
    queries = random_bipolar(rng, (20, D))

    mem = NonIdealDifferentialConductanceMemory(prototypes, seed=111)
    res = mem.similarity_margins_batch(queries)

    assert "margins" in res
    assert "top1_classes" in res
    assert "top2_classes" in res
    assert res["margins"].shape == (20,)
    # Margin must be non-negative
    assert np.all(res["margins"] >= 0.0)
    # top-1 score - top-2 score == margin
    assert np.allclose(res["top1_scores"] - res["top2_scores"], res["margins"], atol=1e-12)

