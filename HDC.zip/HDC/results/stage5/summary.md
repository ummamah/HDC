# Stage 5 & 6 Results: Hardware Non-Idealities & Retrieval Margin Analysis

Evaluated on held-out test sets across 10 repeated stratified splits (white wine dataset, deduplicated protocol).

## 1. Non-Ideality Robustness Sweeps (Task = Original 7-class Quality)

### Model: HDC Single-Pass (Binary AM)

#### Non-Ideality: `ideal`

| Parameter | Value | Macro-F1 | Balanced Acc. | Accuracy | Retrieval Error Rate |
|---|---|---|---|---|---|
| none | 0.0 | 0.214 ± 0.015 | 0.269 ± 0.032 | 0.341 ± 0.017 | nan ± nan |

#### Non-Ideality: `programming_variation`

| Parameter | Value | Macro-F1 | Balanced Acc. | Accuracy | Retrieval Error Rate |
|---|---|---|---|---|---|
| sigma_prog | 0.05 | 0.214 ± 0.014 | 0.268 ± 0.031 | 0.340 ± 0.016 | 0.014 ± 0.004 |
| sigma_prog | 0.1 | 0.213 ± 0.015 | 0.268 ± 0.032 | 0.339 ± 0.016 | 0.027 ± 0.008 |
| sigma_prog | 0.15 | 0.214 ± 0.013 | 0.267 ± 0.029 | 0.342 ± 0.015 | 0.040 ± 0.014 |
| sigma_prog | 0.2 | 0.212 ± 0.013 | 0.267 ± 0.030 | 0.340 ± 0.015 | 0.058 ± 0.018 |
| sigma_prog | 0.25 | 0.212 ± 0.012 | 0.264 ± 0.027 | 0.343 ± 0.016 | 0.080 ± 0.028 |
| sigma_prog | 0.3 | 0.211 ± 0.013 | 0.266 ± 0.028 | 0.340 ± 0.015 | 0.089 ± 0.028 |

#### Non-Ideality: `read_noise`

| Parameter | Value | Macro-F1 | Balanced Acc. | Accuracy | Retrieval Error Rate |
|---|---|---|---|---|---|
| sigma_read | 0.05 | 0.214 ± 0.013 | 0.268 ± 0.030 | 0.340 ± 0.016 | 0.015 ± 0.005 |
| sigma_read | 0.1 | 0.213 ± 0.013 | 0.267 ± 0.030 | 0.340 ± 0.015 | 0.030 ± 0.009 |
| sigma_read | 0.15 | 0.213 ± 0.013 | 0.267 ± 0.030 | 0.340 ± 0.015 | 0.044 ± 0.014 |
| sigma_read | 0.2 | 0.213 ± 0.012 | 0.268 ± 0.030 | 0.341 ± 0.014 | 0.059 ± 0.019 |

#### Non-Ideality: `adc_quantization`

| Parameter | Value | Macro-F1 | Balanced Acc. | Accuracy | Retrieval Error Rate |
|---|---|---|---|---|---|
| adc_bits | 1.0 | 0.001 ± 0.000 | 0.143 ± 0.000 | 0.005 ± 0.000 | 0.978 ± 0.017 |
| adc_bits | 2.0 | 0.036 ± 0.056 | 0.157 ± 0.023 | 0.056 ± 0.082 | 0.908 ± 0.130 |
| adc_bits | 3.0 | 0.082 ± 0.049 | 0.179 ± 0.045 | 0.082 ± 0.050 | 0.863 ± 0.068 |
| adc_bits | 4.0 | 0.070 ± 0.056 | 0.168 ± 0.043 | 0.089 ± 0.099 | 0.856 ± 0.159 |
| adc_bits | 6.0 | 0.190 ± 0.018 | 0.258 ± 0.033 | 0.288 ± 0.041 | 0.361 ± 0.110 |
| adc_bits | 8.0 | 0.208 ± 0.011 | 0.270 ± 0.032 | 0.331 ± 0.013 | 0.097 ± 0.036 |

#### Non-Ideality: `stuck_at_faults`

| Parameter | Value | Macro-F1 | Balanced Acc. | Accuracy | Retrieval Error Rate |
|---|---|---|---|---|---|
| p_saf | 0.01 | 0.214 ± 0.014 | 0.269 ± 0.031 | 0.341 ± 0.015 | 0.029 ± 0.009 |
| p_saf | 0.02 | 0.212 ± 0.013 | 0.267 ± 0.030 | 0.340 ± 0.015 | 0.041 ± 0.012 |
| p_saf | 0.05 | 0.215 ± 0.013 | 0.269 ± 0.030 | 0.344 ± 0.016 | 0.066 ± 0.021 |
| p_saf | 0.1 | 0.211 ± 0.012 | 0.264 ± 0.026 | 0.343 ± 0.015 | 0.103 ± 0.034 |

### Model: HDC + Retraining (Binary AM)

#### Non-Ideality: `ideal`

| Parameter | Value | Macro-F1 | Balanced Acc. | Accuracy | Retrieval Error Rate |
|---|---|---|---|---|---|
| none | 0.0 | 0.233 ± 0.033 | 0.248 ± 0.029 | 0.444 ± 0.048 | nan ± nan |

#### Non-Ideality: `programming_variation`

| Parameter | Value | Macro-F1 | Balanced Acc. | Accuracy | Retrieval Error Rate |
|---|---|---|---|---|---|
| sigma_prog | 0.05 | 0.233 ± 0.033 | 0.248 ± 0.029 | 0.444 ± 0.047 | 0.009 ± 0.006 |
| sigma_prog | 0.1 | 0.233 ± 0.033 | 0.248 ± 0.029 | 0.443 ± 0.046 | 0.018 ± 0.010 |
| sigma_prog | 0.15 | 0.232 ± 0.033 | 0.248 ± 0.028 | 0.444 ± 0.046 | 0.028 ± 0.016 |
| sigma_prog | 0.2 | 0.232 ± 0.032 | 0.248 ± 0.028 | 0.443 ± 0.046 | 0.040 ± 0.020 |
| sigma_prog | 0.25 | 0.232 ± 0.031 | 0.248 ± 0.028 | 0.444 ± 0.042 | 0.054 ± 0.031 |
| sigma_prog | 0.3 | 0.229 ± 0.032 | 0.247 ± 0.028 | 0.440 ± 0.043 | 0.062 ± 0.031 |

#### Non-Ideality: `read_noise`

| Parameter | Value | Macro-F1 | Balanced Acc. | Accuracy | Retrieval Error Rate |
|---|---|---|---|---|---|
| sigma_read | 0.05 | 0.234 ± 0.032 | 0.248 ± 0.028 | 0.445 ± 0.047 | 0.010 ± 0.005 |
| sigma_read | 0.1 | 0.233 ± 0.032 | 0.248 ± 0.028 | 0.445 ± 0.046 | 0.020 ± 0.010 |
| sigma_read | 0.15 | 0.234 ± 0.033 | 0.249 ± 0.029 | 0.444 ± 0.046 | 0.030 ± 0.015 |
| sigma_read | 0.2 | 0.232 ± 0.031 | 0.248 ± 0.029 | 0.444 ± 0.044 | 0.039 ± 0.020 |

#### Non-Ideality: `adc_quantization`

| Parameter | Value | Macro-F1 | Balanced Acc. | Accuracy | Retrieval Error Rate |
|---|---|---|---|---|---|
| adc_bits | 1.0 | 0.001 ± 0.000 | 0.143 ± 0.000 | 0.005 ± 0.000 | 0.999 ± 0.001 |
| adc_bits | 2.0 | 0.065 ± 0.081 | 0.185 ± 0.057 | 0.131 ± 0.163 | 0.799 ± 0.265 |
| adc_bits | 3.0 | 0.091 ± 0.048 | 0.208 ± 0.055 | 0.143 ± 0.080 | 0.769 ± 0.128 |
| adc_bits | 4.0 | 0.090 ± 0.067 | 0.187 ± 0.043 | 0.163 ± 0.148 | 0.744 ± 0.246 |
| adc_bits | 6.0 | 0.206 ± 0.037 | 0.235 ± 0.034 | 0.393 ± 0.073 | 0.257 ± 0.108 |
| adc_bits | 8.0 | 0.229 ± 0.033 | 0.247 ± 0.029 | 0.441 ± 0.050 | 0.061 ± 0.033 |

#### Non-Ideality: `stuck_at_faults`

| Parameter | Value | Macro-F1 | Balanced Acc. | Accuracy | Retrieval Error Rate |
|---|---|---|---|---|---|
| p_saf | 0.01 | 0.234 ± 0.033 | 0.249 ± 0.029 | 0.445 ± 0.045 | 0.020 ± 0.013 |
| p_saf | 0.02 | 0.233 ± 0.033 | 0.248 ± 0.029 | 0.443 ± 0.046 | 0.027 ± 0.015 |
| p_saf | 0.05 | 0.232 ± 0.033 | 0.247 ± 0.029 | 0.444 ± 0.045 | 0.045 ± 0.023 |
| p_saf | 0.1 | 0.230 ± 0.031 | 0.246 ± 0.028 | 0.443 ± 0.044 | 0.068 ± 0.037 |

## 2. Research Question Analysis: Margin vs. Retrieval Reliability (Stage 6)

Hypothesis: *Can the similarity margin between highest- and second-highest-scoring classes predict retrieval errors under non-idealities?*

| Non-Ideality Type | Parameter Value | Total Queries | Retrieval Errors | Error Rate | AUROC (Predicting Retrieval Error from Margin) | AUROC (Predicting Task Error) |
|---|---|---|---|---|---|---|
| adc_quantization | 1 | 7930 | 7758 | 0.978 | **0.438** | 0.450 |
| adc_quantization | 2 | 7930 | 7200 | 0.908 | **0.702** | 0.672 |
| adc_quantization | 3 | 7930 | 6843 | 0.863 | **0.550** | 0.542 |
| adc_quantization | 4 | 7930 | 6788 | 0.856 | **0.728** | 0.687 |
| adc_quantization | 6 | 7930 | 2864 | 0.361 | **0.784** | 0.631 |
| adc_quantization | 8 | 7930 | 768 | 0.097 | **0.917** | 0.598 |
| programming_variation | 0.05 | 7930 | 123 | 0.016 | **0.982** | 0.586 |
| programming_variation | 0.1 | 7930 | 186 | 0.023 | **0.976** | 0.587 |
| programming_variation | 0.15 | 7930 | 298 | 0.038 | **0.965** | 0.579 |
| programming_variation | 0.2 | 7930 | 471 | 0.059 | **0.951** | 0.585 |
| programming_variation | 0.25 | 7930 | 676 | 0.085 | **0.913** | 0.593 |
| programming_variation | 0.3 | 7930 | 673 | 0.085 | **0.916** | 0.579 |
| read_noise | 0.05 | 7930 | 120 | 0.015 | **0.984** | 0.586 |
| read_noise | 0.1 | 7930 | 246 | 0.031 | **0.967** | 0.583 |
| read_noise | 0.15 | 7930 | 349 | 0.044 | **0.955** | 0.584 |
| read_noise | 0.2 | 7930 | 483 | 0.061 | **0.944** | 0.578 |
| stuck_at_faults | 0.01 | 7930 | 272 | 0.034 | **0.969** | 0.591 |
| stuck_at_faults | 0.02 | 7930 | 285 | 0.036 | **0.964** | 0.583 |
| stuck_at_faults | 0.05 | 7930 | 540 | 0.068 | **0.929** | 0.566 |
| stuck_at_faults | 0.1 | 7930 | 778 | 0.098 | **0.892** | 0.567 |
